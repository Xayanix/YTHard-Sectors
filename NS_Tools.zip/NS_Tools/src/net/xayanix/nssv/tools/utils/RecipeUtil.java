package net.xayanix.nssv.tools.utils;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

public class RecipeUtil {

	private static ItemStack stoniarkai;
	private static ItemStack boyfarmer;
	private static ItemStack sandfarmer;
	
	public static void register(){
		stoniarka();
		boyfarmer();
		sandfarmer();
		
		ShapedRecipe stoniarka = new ShapedRecipe(stoniarkai);
		stoniarka.shape("WSW", "RPR", "SRS");
		stoniarka.setIngredient('W', Material.WOOD);
		stoniarka.setIngredient('S', Material.STONE);
		stoniarka.setIngredient('R', Material.REDSTONE_BLOCK);
		stoniarka.setIngredient('P', Material.PISTON_BASE);
		
		ShapedRecipe stoniarka2 = new ShapedRecipe(new ItemStack(Material.ENDER_CHEST));
		stoniarka2.shape("WWW", "WSW", "WWW");
		stoniarka2.setIngredient('W', Material.OBSIDIAN);
		stoniarka2.setIngredient('S', Material.ENDER_PEARL);
		
		ShapedRecipe stoniarka3 = new ShapedRecipe(boyfarmer);
		stoniarka3.shape("ORO", "RDR", "ORO");
		stoniarka3.setIngredient('O', Material.OBSIDIAN);
		stoniarka3.setIngredient('R', Material.REDSTONE);
		stoniarka3.setIngredient('D', Material.DIAMOND);
		
		ShapedRecipe stoniarka4 = new ShapedRecipe(sandfarmer);
		stoniarka4.shape("ORO", "RDR", "ORO");
		stoniarka4.setIngredient('O', Material.SAND);
		stoniarka4.setIngredient('R', Material.REDSTONE);
		stoniarka4.setIngredient('D', Material.DIAMOND);

		Bukkit.getServer().addRecipe(stoniarka);
		Bukkit.getServer().addRecipe(stoniarka2);
		Bukkit.getServer().addRecipe(stoniarka3);
		Bukkit.getServer().addRecipe(stoniarka4);
	}
	
	private static void stoniarka(){
		stoniarkai = new ItemStack(Material.ENDER_STONE, 1);
		ItemMeta im = stoniarkai.getItemMeta();
		im.setDisplayName(ChatUtil.fixColors("&aSTONIARKA"));
		stoniarkai.setItemMeta(im);
	}
	
	public static ItemStack boyfarmer(){
		boyfarmer = new ItemStack(Material.SPONGE, 1);
		ItemMeta im = boyfarmer.getItemMeta();
		im.setDisplayName(ChatUtil.fixColors("&eBOYFARMER"));
		boyfarmer.setItemMeta(im);
		return boyfarmer;
	}
	
	public static ItemStack sandfarmer(){
		sandfarmer = new ItemStack(Material.SPONGE, 1);
		ItemMeta im = sandfarmer.getItemMeta();
		im.setDisplayName(ChatUtil.fixColors("&eSANDFARMER"));
		sandfarmer.setItemMeta(im);
		return sandfarmer;
	}
	
	public static ItemStack stoniarkaItem(){
		return stoniarkai;
	}
}
