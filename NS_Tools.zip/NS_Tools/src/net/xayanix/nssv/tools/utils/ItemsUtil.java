package net.xayanix.nssv.tools.utils;

import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Dawid_2 on 2015-10-11.
 */
public class ItemsUtil {


	public static void recalculateDurability(Player player, ItemStack item)
	{
		if (item.getType().getMaxDurability() == 0) {
			return;
		}
		int enchantLevel = item.getEnchantmentLevel(Enchantment.DURABILITY);
		short d = item.getDurability();
		if (enchantLevel > 0)
		{
			if (100 / (enchantLevel + 1) > RandomUtil.getRandInt(0, 100)) {
				if (d == item.getType().getMaxDurability())
				{
					player.getInventory().clear(player.getInventory().getHeldItemSlot());
					player.playSound(player.getLocation(), Sound.ITEM_BREAK, 1.0F, 1.0F);
				}
				else
				{
					item.setDurability((short)(d + 1));
				}
			}
		}
		else if (d == item.getType().getMaxDurability())
		{
			player.getInventory().clear(player.getInventory().getHeldItemSlot());
			player.playSound(player.getLocation(), Sound.ITEM_BREAK, 1.0F, 1.0F);
		}
		else
		{
			item.setDurability((short)(d + 1));
		}
	}

	public static void addItemsToPlayer(Player player, List<ItemStack> items, Block b)
	{
		PlayerInventory inv = player.getInventory();
		HashMap<Integer, ItemStack> notStored = inv.addItem((ItemStack[])items.toArray(new ItemStack[items.size()]));
		for (Map.Entry<Integer, ItemStack> en : notStored.entrySet()) {
			b.getWorld().dropItemNaturally(b.getLocation(), (ItemStack)en.getValue());
		}
	}

	public static void addItemsToPlayer(Player player, ItemStack items, Block b)
	{
		PlayerInventory inv = player.getInventory();
		HashMap<Integer, ItemStack> notStored = inv.addItem(items);
		for (Map.Entry<Integer, ItemStack> en : notStored.entrySet()) {
			b.getWorld().dropItemNaturally(b.getLocation(), (ItemStack)en.getValue());
		}
	}
	
	public static int additionalDrop(ItemStack is){
		if(is == null) return 0;
		if(!is.containsEnchantment(Enchantment.LOOT_BONUS_BLOCKS)) return 0;
		int level = is.getEnchantmentLevel(Enchantment.LOOT_BONUS_BLOCKS);
		return level;
	}
}
