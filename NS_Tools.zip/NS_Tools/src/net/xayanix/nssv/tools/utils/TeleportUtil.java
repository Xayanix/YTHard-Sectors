package net.xayanix.nssv.tools.utils;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import net.xayanix.nssv.tools.basic.Main;

public class TeleportUtil {

	public static void teleport(final Player player, final Location location, int seconds){
		final Location ploc = player.getLocation();
		if(player.hasPermission("admin")){
			ChatUtil.sendMessage(player, "&8#&c Teleportacja bez oczekiwania (ADMIN)...");
			player.teleport(location);
			return;
		}
		ChatUtil.sendMessage(player, "&8#&c Trwa teleportacja (&7" + seconds + " sekund&c)...");
		Bukkit.getServer().getScheduler().runTaskLater(Main.getInstance(), new Runnable() {
			public void run() {
				if(!player.isOnline()) return;
				if(ploc.distance(player.getLocation()) > 1){
					player.sendMessage(ChatUtil.fixColors("&8#&c Ruszyles sie, teleportacja przerwana."));
					return;
				}
				player.teleport(location);
			}
		}, 20 * seconds);
	}
	
}
