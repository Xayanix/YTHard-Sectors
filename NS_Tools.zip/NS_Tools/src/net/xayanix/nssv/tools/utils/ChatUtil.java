package net.xayanix.nssv.tools.utils;

import java.util.List;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;


public class ChatUtil {
	public static String fixColors(String message) {
		if(message == null){
			return "";
		}
		return (org.bukkit.ChatColor.translateAlternateColorCodes('&', message)).replace("#", " �");
	}

	public static String[] fixColors(String[] message) {
		String[] strings = message;
		for (int i = 0; i < strings.length; i++) {
			strings[i] = fixColors(strings[i]);
		}
		return strings;
	}

	public static void sendMessage(Player p, String message) {
		p.sendMessage(ChatUtil.fixColors(message));
	}
	
	public static void sendMessage(CommandSender cs, String message) {
		cs.sendMessage(ChatUtil.fixColors(message));
	}
	
	public static void sendMessage(Player p, String[] messages) {
		p.sendMessage(fixColors(messages));
	}

	public static void sendMessage(Player p, List<String> message) {
		for (int i = 0; i < message.size(); i++) {
			sendMessage(p, message.get(i));
		}
	}
}
