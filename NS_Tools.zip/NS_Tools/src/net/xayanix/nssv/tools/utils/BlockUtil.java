package net.xayanix.nssv.tools.utils;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

public class BlockUtil {

	public static void farmer(Location location, Material material){
		int count = 0;

		double x = location.getX();
		double y = location.getY();
		double z = location.getZ();

		while(count <= 300)
		{
			Location loc = new Location(location.getWorld(), x, y, z);
			Block block = loc.getBlock();
			if(block.getType() == Material.BEDROCK) return;
			block.setType(material);
			y = y - 1;
		}
	}
	
	public static List<Location> sphere(Location loc, int radius, int height, boolean hollow, boolean sphere, int plusY){
		List<Location> circleblocks = new ArrayList<Location>();
		int cx = loc.getBlockX();
		int cy = loc.getBlockY();
		int cz = loc.getBlockZ();

		for(int x = cx - radius; x <= cx + radius; x++){
			for (int z = cz - radius; z <= cz + radius; z++){
				for(int y = (sphere ? cy - radius : cy); y < (sphere ? cy + radius : cy + height); y++){
					double dist = (cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? (cy - y) * (cy - y) : 0);

					if(dist < radius * radius && !(hollow && dist < (radius - 1) * (radius - 1))){
						Location l = new Location(loc.getWorld(), x, y + plusY, z);
						circleblocks.add(l);
					}
				}
			}
		}
		return circleblocks;
	}
	
}
