package net.xayanix.nssv.tools.task;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.bukkit.Bukkit;

import com.mysql.jdbc.Statement;

import net.xayanix.nssv.tools.basic.Main;
import net.xayanix.nssv.tools.managers.DatabaseManager;

public class CommandsTask implements Runnable{
	
	private static int lastQueryId = 0;

	@Override
	public void run() {
		doo();
	}
	
	public void start(){
		Bukkit.getScheduler().runTaskTimerAsynchronously(Main.getInstance(), this, 20, 20);
	}

	
	public static void doo(){
		if(DatabaseManager.con == null) return;
		Statement st = null;
		try {
			st = (Statement) DatabaseManager.getConnection().createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			ResultSet rs = st.executeQuery("SELECT * FROM `sync_manager` WHERE `id` > " + lastQueryId + " AND `server` = 'sektor' ORDER BY `id` ASC");
			Integer bane = 0;
			
			while(rs.next()){
				lastQueryId = rs.getInt("id");
				Bukkit.dispatchCommand(Bukkit.getConsoleSender(), rs.getString("command"));
				bane++;
			}
			rs.close();
			if(bane > 0) System.out.format("[NS_Sync] " + bane + " synchronized.");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void truncate(){
		DatabaseManager.executeQuery("TRUNCATE `sync_manager`");
	}
}
