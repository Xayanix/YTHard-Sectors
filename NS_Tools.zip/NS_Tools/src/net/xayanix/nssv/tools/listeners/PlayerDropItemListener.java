package net.xayanix.nssv.tools.listeners;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.ItemStack;

import net.xayanix.nssv.sektory.utils.ChatUtil;

public class PlayerDropItemListener implements Listener{
	
	@EventHandler
	public void onDrop(PlayerDropItemEvent event){
		Player player = event.getPlayer();
		
		if(player.getGameMode() == GameMode.CREATIVE) {
			event.setCancelled(true);
			player.getInventory().clear();
			player.getEnderChest().clear();
			player.getInventory().setHelmet(new ItemStack(Material.AIR, 1));
			player.getInventory().setChestplate(new ItemStack(Material.AIR, 1));
			player.getInventory().setLeggings(new ItemStack(Material.AIR, 1));
			player.getInventory().setBoots(new ItemStack(Material.AIR, 1));
			player.sendMessage(ChatUtil.fixColors("&8#&c Ekwipunek wyczyszczony."));
		}
	}

}
