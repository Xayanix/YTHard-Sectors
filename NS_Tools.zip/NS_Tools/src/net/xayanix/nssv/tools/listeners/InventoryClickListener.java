package net.xayanix.nssv.tools.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class InventoryClickListener implements Listener{
	
	@EventHandler
	public void onClick(InventoryClickEvent event){
		if(event.getInventory() == null) return;
		if(event.getInventory().getName() == null) return;
		if(!event.getInventory().getName().equalsIgnoreCase("�7CRAFTINGI") && !event.getInventory().getName().equalsIgnoreCase("�7DROP")) return;
		event.setCancelled(true);
		((Player) event.getWhoClicked()).closeInventory();
		if(event.getSlot() == 53){
			((Player) event.getWhoClicked()).chat("/craft 2");
		}
		else if (event.getSlot() == 45){
			((Player) event.getWhoClicked()).chat("/craft");
		}
	}

}
