package net.xayanix.nssv.tools.listeners;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import net.xayanix.nssv.tools.basic.Main;
import net.xayanix.nssv.tools.drop.Drop;
import net.xayanix.nssv.tools.utils.ItemsUtil;
import net.xayanix.nssv.tools.utils.RandomUtil;

public class BlockBreakListener implements Listener{
	
	public static List<String> cobble_off = new ArrayList<String>();
	
	@EventHandler(priority = EventPriority.HIGHEST)
	public void onBreak(BlockBreakEvent event){
		if(event.isCancelled()) return;
		
		Player player = event.getPlayer();
		final Block block = event.getBlock();
		Location above = block.getLocation().add(0.0, -1.0, 0.0);
		
		if(block.getType() == Material.STONE){
			if(above.getBlock().getType() == Material.ENDER_STONE){
				Bukkit.getServer().getScheduler().runTaskLater(Main.getInstance(), new Runnable() {
					public void run() {
						block.setType(Material.STONE);
					}
				}, 20);
			}
			
			player.giveExp(5);
			if(cobble_off.contains(player.getName())){
				event.getBlock().setType(Material.AIR);
			}
			
			for(Drop d : Drop.drops){
				
				Double chance = d.getChance();
				if(player.hasPermission("vip")) chance = chance * 2;
				
				
				if(RandomUtil.getChance(chance)){
					if(ItemsUtil.additionalDrop(player.getItemInHand()) > 0){
						for(int i = 0; i < ItemsUtil.additionalDrop(player.getItemInHand()); i++){
							player.getInventory().addItem(d.getItem());
						}
						
					}
					else player.getInventory().addItem(d.getItem());
				}
			}
			ItemsUtil.recalculateDurability(player, player.getItemInHand());
		}
		else if(block.getType() == Material.DIAMOND_ORE || block.getType() == Material.GOLD_ORE || block.getType() == Material.IRON_ORE || block.getType() == Material.COAL_ORE || block.getType() == Material.LAPIS_ORE || block.getType() == Material.EMERALD_ORE){
			event.setCancelled(true);
			block.setType(Material.AIR);
		}
		
		int count = 0;
		for (ItemStack i : player.getInventory()) {
			if (i == null) {
				count++;
			}
		}
		if (count != 0 && block.getType() != Material.NETHER_WARTS && block.getType() != Material.CARROT && block.getType() != Material.POTATO && block.getType() != Material.ENDER_CHEST && block.getType() != Material.LEAVES) {
			Collection<ItemStack> Itemy = event.getBlock().getDrops();
			for (ItemStack i : Itemy) {
				player.getInventory().addItem(new ItemStack[] { i });
			}
			event.getBlock().setType(Material.AIR);
		}
		
	}

}
