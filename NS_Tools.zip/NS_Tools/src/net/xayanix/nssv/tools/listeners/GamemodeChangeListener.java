package net.xayanix.nssv.tools.listeners;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.inventory.ItemStack;

import net.xayanix.nssv.tools.utils.ChatUtil;

public class GamemodeChangeListener implements Listener{
	
	@EventHandler
	public void onGamemode(PlayerGameModeChangeEvent event){
		if(event.getPlayer().getGameMode() == GameMode.CREATIVE) {
			event.getPlayer().getInventory().clear();
			event.getPlayer().getEnderChest().clear();
			event.getPlayer().getInventory().setHelmet(new ItemStack(Material.AIR, 1));
			event.getPlayer().getInventory().setChestplate(new ItemStack(Material.AIR, 1));
			event.getPlayer().getInventory().setLeggings(new ItemStack(Material.AIR, 1));
			event.getPlayer().getInventory().setBoots(new ItemStack(Material.AIR, 1));
			event.getPlayer().sendMessage(ChatUtil.fixColors("&8#&c Ekwipunek wyczyszczony."));
		}
	}

}
