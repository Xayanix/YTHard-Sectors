package net.xayanix.nssv.tools.listeners;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import net.xayanix.nssv.sektory.utils.ChatUtil;
import net.xayanix.nssv.tools.utils.LocationUtil;

public class PlayerInteractListener implements Listener{
	
	@EventHandler
	public void onInteract(PlayerInteractEvent event){
		Player player = event.getPlayer();
		Block cblock = event.getClickedBlock();
		
		if(event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
		Location block = cblock.getLocation().add(1.0D, 0.0D, 0.0D);
		Location block1 = cblock.getLocation().add(-1.0D, 0.0D, 0.0D);
		Location block2 = cblock.getLocation().add(0.0D, 0.0D, 1.0D);
		Location block3 = cblock.getLocation().add(0.0D, 0.0D, -1.0D);
		
		
		if(cblock.getType() == Material.BEACON){
			cblock.setType(Material.AIR);
			ChatUtil.sendMessage(player, "&8#&c Beacony sa wylaczone.");
		}
		else if(cblock.getType() == Material.CHEST){
			if(player.getGameMode() == GameMode.CREATIVE) {
				player.getInventory().clear();
				player.getEnderChest().clear();
				player.getInventory().setHelmet(new ItemStack(Material.AIR, 1));
				player.getInventory().setChestplate(new ItemStack(Material.AIR, 1));
				player.getInventory().setLeggings(new ItemStack(Material.AIR, 1));
				player.getInventory().setBoots(new ItemStack(Material.AIR, 1));
				player.sendMessage(ChatUtil.fixColors("&8#&c Ekwipunek wyczyszczony."));
			}
		}
		else if(cblock.getType() != Material.STONE_BUTTON && cblock.getType() != Material.WOOD_BUTTON) return;
		else if(block.getBlock().getType() == Material.SPONGE || block1.getBlock().getType() == Material.SPONGE || block2.getBlock().getType() == Material.SPONGE || block3.getBlock().getType() == Material.SPONGE){
			LocationUtil.teleportRandom(player);
		}
		else if(block.getBlock().getType() == Material.JUKEBOX || block1.getBlock().getType() == Material.JUKEBOX || block2.getBlock().getType() == Material.JUKEBOX || block3.getBlock().getType() == Material.JUKEBOX){
			Location location = LocationUtil.getValidRandomCords();
			for(Player p : LocationUtil.getPlayersInRadius(cblock.getLocation(), 5)){
				p.teleport(location);
			}
		}
		
		
	}

}
