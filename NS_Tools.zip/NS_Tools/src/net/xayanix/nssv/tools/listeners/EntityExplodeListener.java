package net.xayanix.nssv.tools.listeners;

import java.util.List;

import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.inventory.ItemStack;

import net.xayanix.nssv.tools.utils.BlockUtil;
import net.xayanix.nssv.tools.utils.RandomUtil;

public class EntityExplodeListener implements Listener{
	
	@EventHandler(priority = EventPriority.HIGHEST)
	public void onExplode(EntityExplodeEvent event){
		if(event.isCancelled()) return;
		Location loc = event.getLocation();
		List<Location> sphere = BlockUtil.sphere(loc, 4, 4, false, true, 0);
		for(Location l : sphere){
			Material material = l.getBlock().getType();
			
			if (material==Material.WATER || material==Material.STATIONARY_WATER||material==Material.LAVA||material==Material.STATIONARY_LAVA){
				if(RandomUtil.getChance(25.0)){
					l.getBlock().setType(Material.COBBLESTONE);
				}
			}
			
			if(material == Material.ENDER_CHEST || material==Material.OBSIDIAN || material==Material.ANVIL || material==Material.ENCHANTMENT_TABLE){
				if(RandomUtil.getChance(10.0)){
					l.getBlock().setType(Material.AIR);
				}
			}
			if (material==Material.BEACON){
				l.getBlock().setType(Material.AIR);
				l.getBlock().getWorld().dropItemNaturally(l, new ItemStack(Material.BEACON));
				l.getBlock().getWorld().playEffect(l, Effect.EXPLOSION_LARGE, 3);
			}
		}
	}

}
