package net.xayanix.nssv.tools.listeners;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import net.xayanix.nssv.tools.basic.Main;
import net.xayanix.nssv.tools.utils.BlockUtil;
import net.xayanix.nssv.tools.utils.ChatUtil;
import net.xayanix.nssv.tools.utils.ItemBuilder;
import net.xayanix.nssv.tools.utils.RandomUtil;

public class BlockPlaceListener implements Listener{
	
	@EventHandler(priority = EventPriority.HIGHEST)
	public void onPlace(BlockPlaceEvent event){
		if(event.isCancelled()) return;
		
		Player p = event.getPlayer();
		Block block = event.getBlock();
		final Location above = block.getLocation().add(0.0, 1.0, 0.0);
		
		if(block.getType() == Material.ENDER_STONE){
			Bukkit.getServer().getScheduler().runTaskLater(Main.getInstance(), new Runnable() {
				public void run() {
					above.getBlock().setType(Material.STONE);
				}
			}, 20);
			
		}
		else if(block.getType() == Material.DRAGON_EGG){
			block.setType(Material.AIR);
			
			int random = RandomUtil.getRandInt(1, 14);
			if (random == 1) {
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i zalala go lawa").replace("&", "�"));
				Location loc = p.getLocation();
				loc.getBlock().setType(Material.LAVA);
			}
			else if (random == 2) {
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i zaatakowany go Zombie").replace("&", "�"));
				final Zombie zombie = (Zombie) p.getLocation().getWorld().spawnEntity(p.getLocation(), EntityType.ZOMBIE);
				zombie.setCustomName(ChatUtil.fixColors("&c&lMANIEK"));
				zombie.setBaby(true);
				zombie.setCustomNameVisible(true);
				zombie.setMaxHealth(80.0);
				zombie.getEquipment().setHelmet(new ItemStack(Material.DIAMOND_HELMET));
				zombie.getEquipment().setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
				zombie.getEquipment().setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
				zombie.getEquipment().setBoots(new ItemStack(Material.DIAMOND_BOOTS));
				zombie.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 18000, 1));
				p.setFireTicks(1000);
				p.setCustomName(ChatUtil.fixColors("&2&lYTHARD"));
				p.setCustomNameVisible(true);
			}
			else if (random == 3) {
				TNTPrimed tnt = (TNTPrimed) p.getLocation().getWorld().spawnEntity(p.getLocation().add(0, 1, 0), EntityType.PRIMED_TNT);
				tnt.setFallDistance(5);
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i zostal wysadzony w powietrze").replace("&", "�"));
			}
			else if (random == 4) {
				int koxint = RandomUtil.getRandInt(1, 3);
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i wylosowal Koxy (" + koxint + "szt.)").replace("&", "�"));
				p.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE, koxint, (short)1));
				p.updateInventory();
			}
			else if (random == 5) {
				int refilint = RandomUtil.getRandInt(1, 6);
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i wylosowal Refile (" + refilint + "szt.)").replace("&", "�"));
				p.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE, refilint));
				p.updateInventory();
			}
			else if (random == 6) {
				int pierogint = RandomUtil.getRandInt(1, 2);
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i wylosowal Magiczne Pierozki (" + pierogint + "szt.)").replace("&", "�"));
				final ItemBuilder item = new ItemBuilder(Material.DRAGON_EGG, pierogint).setTitle(ChatUtil.fixColors("&6MAGICZNY PIEROZEK")).addLore(ChatUtil.fixColors("&7&oZawiera jeden z unikalnych itemow")).addLore(ChatUtil.fixColors("&7&oLista pod komenda /pomoc")).addLore(ChatUtil.fixColors("&e&nAby otworzyc postaw na ziemi!"));
				p.getInventory().addItem(item.build());
				p.updateInventory();
			}
			else if (random == 7) {
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i wylosowal Helm Protection 4 Unbreaking 3").replace("&", "�"));
				final ItemBuilder item = new ItemBuilder(Material.DIAMOND_HELMET).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 4).addEnchantment(Enchantment.DURABILITY, 3);
				p.getInventory().addItem(item.build());
				p.updateInventory();
			}
			else if (random == 8) {
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i wylosowal Klate Protection 4 Unbreaking 3").replace("&", "�"));
				final ItemBuilder item = new ItemBuilder(Material.DIAMOND_CHESTPLATE).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 4).addEnchantment(Enchantment.DURABILITY, 3);

				p.getInventory().addItem(item.build());
				p.updateInventory();
			}
			else if (random == 9) {
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i wylosowal Spodnie Protection 4 Unbreaking 3").replace("&", "�"));
				final ItemBuilder item = new ItemBuilder(Material.DIAMOND_LEGGINGS).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 4).addEnchantment(Enchantment.DURABILITY, 3);
				p.getInventory().addItem(item.build());
				p.updateInventory();
			}
			else if (random == 10) {
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i wylosowal Buty Protection 4 Unbreaking 3").replace("&", "�"));
				final ItemBuilder item = new ItemBuilder(Material.DIAMOND_BOOTS).addEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 4).addEnchantment(Enchantment.DURABILITY, 3);
				p.getInventory().addItem(item.build());
				p.updateInventory();
			}
			else if (random == 11) {
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i wylosowal Miecz Sharpness 5 Unbreaking 3 Fireascept 2").replace("&", "�"));
				final ItemBuilder item = new ItemBuilder(Material.DIAMOND_SWORD).addEnchantment(Enchantment.DAMAGE_ALL, 5).addEnchantment(Enchantment.DURABILITY, 3).addEnchantment(Enchantment.FIRE_ASPECT, 2);
				p.getInventory().addItem(item.build());
				p.updateInventory();
			}
			else if (random == 12) {
				int tntint = RandomUtil.getRandInt(8, 64);
				Bukkit.broadcastMessage(("&8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i wylosowal TNT (" + tntint + ")").replace("&", "�"));
				p.getInventory().addItem(new ItemStack(Material.TNT, tntint));
				p.updateInventory();

			}
			else if (random == 13) {
				int perlaint = RandomUtil.getRandInt(1, 3);
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i wylosowal Perle (" + perlaint + ")").replace("&", "�"));
				p.getInventory().addItem(new ItemStack(Material.ENDER_PEARL, perlaint));
				p.updateInventory();

			}
			else if (random == 14) {
				int bookint = RandomUtil.getRandInt(16, 32);
				Bukkit.broadcastMessage((" &8� &6Gracz &c" + p.getDisplayName() + " &6otworzyl &cMagiczny Pierozek &6i wylosowal Ksiazke (" + bookint + ")").replace("&", "�"));
				p.getInventory().addItem(new ItemStack(Material.BOOK, bookint));
				p.updateInventory();

			}
		}
		else if(block.getType() == Material.SPONGE){
			ItemMeta im = p.getItemInHand().getItemMeta();
			if(im.getDisplayName() != null){
				if(im.getDisplayName().toLowerCase().equalsIgnoreCase(ChatUtil.fixColors("&eBOYFARMER"))){
					BlockUtil.farmer(block.getLocation(), Material.OBSIDIAN);
				}
				else if(im.getDisplayName().toLowerCase().equalsIgnoreCase(ChatUtil.fixColors("&eSANDFARMER"))){
					BlockUtil.farmer(block.getLocation(), Material.SAND);
				}
			}
		}
		else if(block.getType() == Material.STONE){
			ItemMeta im = p.getItemInHand().getItemMeta();
			int i = RandomUtil.getRandInt(0, 28) + 1;
			
			if(im.getDisplayName() != null){
				if(im.getDisplayName().equalsIgnoreCase(ChatUtil.fixColors("&cCOBBLEX"))){
					ChatUtil.sendMessage(p, "&8#&c Wylosowales przedmiot!");
					if(i == 1){
						p.getInventory().addItem(new ItemStack(Material.TNT, 3));
					}
					else if(i == 2){
						p.getInventory().addItem(new ItemStack(Material.SUGAR_CANE, 16));
					}
					else if(i == 3){
						p.getInventory().addItem(new ItemStack(Material.SLIME_BALL, 4));
					}
					else if(i == 4){
						p.getInventory().addItem(new ItemStack(Material.ENDER_PEARL, 3));
					}
					else if(i == 5){
						p.getInventory().addItem(new ItemStack(Material.EMERALD_ORE, 8));
					}
					else if(i == 6){
						p.getInventory().addItem(new ItemStack(Material.LEATHER, 12));
					}
					else if(i == 7){
						p.getInventory().addItem(new ItemStack(Material.APPLE, 8));
					}
					else if(i == 8){
						p.getInventory().addItem(new ItemStack(Material.NETHER_WARTS, 1));
					}
					else if(i == 9){
						p.getInventory().addItem(new ItemStack(Material.GLOWSTONE_DUST, 32));
					}
					else if(i == 10){
						ItemStack d = new ItemStack(Material.DIAMOND_SWORD, 1);
						ItemMeta ae = d.getItemMeta();
						ae.addEnchant(Enchantment.DAMAGE_ALL, 5, true);
						ae.addEnchant(Enchantment.FIRE_ASPECT, 2, true);
						d.setItemMeta(ae);

						p.getInventory().addItem(d);
					}
					else if(i == 11){
						p.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE, 2));
					}
					else if(i == 12){
						p.getInventory().addItem(new ItemStack(Material.DIRT, 32, (short) 2));
					}
					else if(i == 13){
						p.getInventory().addItem(new ItemStack(Material.OBSIDIAN, 24));
					}
					else if(i == 14){
						p.getInventory().addItem(new ItemStack(Material.GOLD_BLOCK, 6));
					}
					else if(i == 15){
						p.getInventory().addItem(new ItemStack(Material.EMERALD_BLOCK, 3));
					}
					else if(i == 16){
						p.getInventory().addItem(new ItemStack(Material.DIAMOND_BLOCK, 2));
					}
					else if(i == 17){
						p.getInventory().addItem(new ItemStack(Material.ARROW, 16));
					}
					else if(i == 18){
						p.getInventory().addItem(new ItemStack(Material.BOOK, 16));
					}
					else if(i == 19){
						p.getInventory().addItem(new ItemStack(Material.SAND, 24));
					}
					else if(i == 20){
						p.getInventory().addItem(new ItemStack(Material.MELON, 12));
					}
					else if(i == 21){
						p.getInventory().addItem(new ItemStack(Material.BLAZE_ROD, 1));
					}
					else if(i == 22){
						p.getInventory().addItem(new ItemStack(Material.EXP_BOTTLE, 12));
					}
					else if(i == 23){
						p.getInventory().addItem(new ItemStack(Material.MONSTER_EGG, 3, (short) 92));
					}
					else if(i == 24){
						p.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE, 1, (short) 1));
					}
					else if(i == 25){
						p.getInventory().addItem(new ItemStack(Material.REDSTONE, 32));
					}
					else if(i == 26){
						p.getInventory().addItem(new ItemStack(Material.LAVA_BUCKET, 1));
					}
					else if(i == 27){
						p.getInventory().addItem(new ItemStack(Material.BOW, 1));
					}
					else if(i == 28){
						p.getInventory().addItem(new ItemStack(Material.IRON_BLOCK, 5));
					}
				}
			}
			
			
		}
		
	}

}
