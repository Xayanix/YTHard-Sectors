package net.xayanix.nssv.tools.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import net.xayanix.nssv.sektory.utils.ChatUtil;

public class VipCommand implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		ChatUtil.sendMessage(arg0, "&8&m�--------� &6&LVIP &8&m�--------�");
		ChatUtil.sendMessage(arg0, "&cVIP POSIADA:");
		ChatUtil.sendMessage(arg0, "&6Exp x2");
		ChatUtil.sendMessage(arg0, "&6Drop x2");
		ChatUtil.sendMessage(arg0, "&6Repair co 3 minuty");
		ChatUtil.sendMessage(arg0, "&6Kit Vip co 3 dni");
		ChatUtil.sendMessage(arg0, "&6komendy: /enderchest /workbench /repair /kit vip ");
		ChatUtil.sendMessage(arg0, "&cKOSZT: &611.07 na edycje &c//30,75 na zawsze :)");
		ChatUtil.sendMessage(arg0, "&8&m�--------� &6&LVIP &8&m�--------�");
		return true;
	}

}
