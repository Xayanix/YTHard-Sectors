package net.xayanix.nssv.tools.commands;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.xayanix.nssv.sektory.utils.ChatUtil;
import net.xayanix.nssv.tools.drop.Drop;

public class DropCommand implements CommandExecutor{

	private static Inventory inv;
	
	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		((Player) arg0).openInventory(inv);
		return true;
	}
	
	public static void dropInventoryPrepare(){
		inv = Bukkit.getServer().createInventory(null, 36, "�7DROP");
		int count = 0;
		for(Drop d : Drop.drops){
			inv.setItem(count, drop(d.getItem(), d.getChance()));
			count++;
		}
		
	}
	
	public static ItemStack drop(ItemStack is, Double chance){
		ItemStack i = new ItemStack(is.getType(), 1);
		ItemMeta im = i.getItemMeta();
		
		im.setDisplayName(ChatUtil.fixColors("&8#&7 PRZEDMIOT: &c" + is.getType().toString()));
		
		List<String> lore = new ArrayList<String>();
		lore.add(ChatUtil.fixColors("&8# &7SZANSA: " + chance + "%"));
		chance = chance * 2;
		lore.add(ChatUtil.fixColors("&8# &6SZANSA VIP: " + chance + "%"));
		im.setLore(lore);
		
		i.setItemMeta(im);
		return i;
	}

}
