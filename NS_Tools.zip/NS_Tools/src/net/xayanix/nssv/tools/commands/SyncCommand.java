package net.xayanix.nssv.tools.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import net.xayanix.nssv.tools.basic.Main;
import net.xayanix.nssv.tools.managers.DatabaseManager;

public class SyncCommand implements CommandExecutor{
	
	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2,
			String[] arg3) {
		if(!arg0.hasPermission("admin")) return false;
		if(arg3.length < 3) return false;
		String ar1 = arg3[0];
		String ar2 = arg3[1];
		String wiadomosc = "";
		for(int i = 2; i < arg3.length; i++){
			wiadomosc = wiadomosc + " " + arg3[i];
		}
		wiadomosc = wiadomosc.replaceFirst(" ", "");
		final String cmd = wiadomosc;
		
		if(ar1.equalsIgnoreCase("console")){
			if(ar2.equalsIgnoreCase("all")){
				Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), new Runnable() {
					@Override
					public void run() {
						DatabaseManager.executeQuery("INSERT INTO `sync_manager` (`id`, `server`, `command`) VALUES (NULL, 'sektor', '" + cmd + "');");
					}});
			}
			else if(ar2.equalsIgnoreCase("bungee")){
				Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), new Runnable() {
					@Override
					public void run() {
						DatabaseManager.executeQuery("INSERT INTO `sync_manager` (`id`, `server`, `command`) VALUES (NULL, 'bungee', '" + cmd + "');");
					}});
			}
		}
		
		return true;
	}
	
}
