package net.xayanix.nssv.tools.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import net.xayanix.nssv.tools.utils.ChatUtil;

public class WwwCommand implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		ChatUtil.sendMessage(arg0, "&8&m�--------� &6&LWWW &8&m�--------�");
		ChatUtil.sendMessage(arg0, "&6Nasza strona to: &cWWW.YTHARD.PL");
		ChatUtil.sendMessage(arg0, "&8&m�--------� &6&LWWW &8&m�--------�");
		
		return true;
	}

}
