package net.xayanix.nssv.tools.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import net.xayanix.nssv.sektory.utils.ChatUtil;

public class YtCommand implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		ChatUtil.sendMessage(arg0, "&8&m�--------� &6&LYT &8&m�--------�");
		ChatUtil.sendMessage(arg0, "&7Aby uzyska� &fyou&4tubera &7na naszym serwerze");
		ChatUtil.sendMessage(arg0, "&7musisz posiadac &6450 widzow &7wstawic ");
		ChatUtil.sendMessage(arg0, "&7reklame serwera i podeslac link na &6helpop ");
		ChatUtil.sendMessage(arg0, "&8&m�--------� &6&LYT &8&m�--------�");
		
		
		return true;
	}

}
