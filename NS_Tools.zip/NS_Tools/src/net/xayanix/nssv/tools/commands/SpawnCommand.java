package net.xayanix.nssv.tools.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.tools.utils.TeleportUtil;

public class SpawnCommand implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		if(!(arg0 instanceof Player)) return false;
		Player player = (Player) arg0;
		
		TeleportUtil.teleport(player, Settings.spawn, 5);
		
		return true;
	}

}
