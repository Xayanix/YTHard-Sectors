package net.xayanix.nssv.tools.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import net.xayanix.nssv.sektory.utils.ChatUtil;
import net.xayanix.nssv.tools.listeners.BlockBreakListener;

public class CobbleCommand implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		if(arg3.length == 0){
			ChatUtil.sendMessage(arg0, "&8#&c /cobble <on/off> - wlacza/wylacz drop cobblestone");
			return false;
		}
		if(arg3[0].equalsIgnoreCase("on")){
			BlockBreakListener.cobble_off.remove(arg0.getName());
			ChatUtil.sendMessage(arg0, "&8#&a Drop cobble wlaczony.");
		}
		else if(arg3[0].equalsIgnoreCase("off")){
			BlockBreakListener.cobble_off.add(arg0.getName());
			ChatUtil.sendMessage(arg0, "&8#&c Drop cobble wylaczony.");
		}
		return true;
	}
	
}
