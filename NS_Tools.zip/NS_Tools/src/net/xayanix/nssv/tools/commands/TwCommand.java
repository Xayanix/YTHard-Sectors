package net.xayanix.nssv.tools.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import net.xayanix.nssv.sektory.utils.ChatUtil;

public class TwCommand implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		ChatUtil.sendMessage(arg0, "&8&m�--------� &6&LTW &8&m�--------�");
		ChatUtil.sendMessage(arg0, "&7Aby uzyska� &5twitchera &7na naszym serwerze");
		ChatUtil.sendMessage(arg0, "&7musisz posiadac &6450 follow &7live ");
		ChatUtil.sendMessage(arg0, "&7musza odbywac sie 2 razy w tygodniu ");
		ChatUtil.sendMessage(arg0, "&8&m�--------� &6&LTW &8&m�--------�");
		
		return true;
	}

}
