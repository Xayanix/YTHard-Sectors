package net.xayanix.nssv.tools.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import net.xayanix.nssv.tools.utils.ChatUtil;

public class HelpCommand implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		ChatUtil.sendMessage(arg0, "&8&m�--------� &6&LPOMOC &8&m�--------�");
		ChatUtil.sendMessage(arg0, "&6/craft &c- pokazuje dostepne craftingi");
		ChatUtil.sendMessage(arg0, "&6/helpop &c- Szybki kontakt do administracji");
		ChatUtil.sendMessage(arg0, "&6/sektor &c- informacje o sektorach");
		ChatUtil.sendMessage(arg0, "&6/vip &c- informacje o vipie");
		ChatUtil.sendMessage(arg0, "&6/g &c- informacje o gildiach");
		ChatUtil.sendMessage(arg0, "&6/ts3 &c-pokazuje teamspeak");
		ChatUtil.sendMessage(arg0, "&6/www &c-pokazuje strone www");
		ChatUtil.sendMessage(arg0, "&6/yt &c- info o youtube");
		ChatUtil.sendMessage(arg0, "&6/tw &C- informacje o twitchu");
		ChatUtil.sendMessage(arg0, "&6/drop &c- informacje o dropie");
		ChatUtil.sendMessage(arg0, "&8&m�--------� &6&LPOMOC &8&m�--------�");
		
		return true;
	}

}
