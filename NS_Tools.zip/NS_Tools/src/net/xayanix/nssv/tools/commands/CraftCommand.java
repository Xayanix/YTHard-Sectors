package net.xayanix.nssv.tools.commands;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.xayanix.nssv.sektory.utils.ChatUtil;
import net.xayanix.nssv.tools.utils.RecipeUtil;

public class CraftCommand implements CommandExecutor{

	private static Inventory inv;
	private static Inventory inv2;
	
	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		if(arg3.length == 0)
			((Player) arg0).openInventory(inv);
		else
			((Player) arg0).openInventory(inv2);
		return true;
	}
	
	public static void craftInventoryPrepare(){
		inv = Bukkit.getServer().createInventory(null, 54, "�7CRAFTINGI");
		inv.setItem(11, RecipeUtil.stoniarkaItem());
		
		inv.setItem(19, new ItemStack(Material.WOOD, 1));
		inv.setItem(20, new ItemStack(Material.STONE, 1));
		inv.setItem(21, new ItemStack(Material.WOOD, 1));
		
		inv.setItem(28, new ItemStack(Material.REDSTONE_BLOCK, 1));
		inv.setItem(29, new ItemStack(Material.PISTON_BASE, 1));
		inv.setItem(30, new ItemStack(Material.REDSTONE_BLOCK, 1));
		
		inv.setItem(37, new ItemStack(Material.STONE, 1));
		inv.setItem(38, new ItemStack(Material.REDSTONE_BLOCK, 1));
		inv.setItem(39, new ItemStack(Material.STONE, 1));
		
		inv.setItem(53, next());
		
		
		inv.setItem(15, new ItemStack(Material.ENDER_CHEST, 1));
		
		inv.setItem(23, new ItemStack(Material.OBSIDIAN, 1));
		inv.setItem(24, new ItemStack(Material.OBSIDIAN, 1));
		inv.setItem(25, new ItemStack(Material.OBSIDIAN, 1));
		
		inv.setItem(32, new ItemStack(Material.OBSIDIAN, 1));
		inv.setItem(33, new ItemStack(Material.ENDER_PEARL, 1));
		inv.setItem(34, new ItemStack(Material.OBSIDIAN, 1));
		
		inv.setItem(41, new ItemStack(Material.OBSIDIAN, 1));
		inv.setItem(42, new ItemStack(Material.OBSIDIAN, 1));
		inv.setItem(43, new ItemStack(Material.OBSIDIAN, 1));
		
		
		inv2 = Bukkit.getServer().createInventory(null, 54, "�7CRAFTINGI");
		inv2.setItem(11, RecipeUtil.boyfarmer());
		
		inv2.setItem(19, new ItemStack(Material.OBSIDIAN, 1));
		inv2.setItem(20, new ItemStack(Material.REDSTONE, 1));
		inv2.setItem(21, new ItemStack(Material.OBSIDIAN, 1));
		
		inv2.setItem(28, new ItemStack(Material.REDSTONE, 1));
		inv2.setItem(29, new ItemStack(Material.DIAMOND, 1));
		inv2.setItem(30, new ItemStack(Material.REDSTONE, 1));
		
		inv2.setItem(37, new ItemStack(Material.OBSIDIAN, 1));
		inv2.setItem(38, new ItemStack(Material.REDSTONE, 1));
		inv2.setItem(39, new ItemStack(Material.OBSIDIAN, 1));
		
		
		inv2.setItem(15, RecipeUtil.sandfarmer());
		
		inv2.setItem(23, new ItemStack(Material.SAND, 1));
		inv2.setItem(24, new ItemStack(Material.REDSTONE, 1));
		inv2.setItem(25, new ItemStack(Material.SAND, 1));
		
		inv2.setItem(32, new ItemStack(Material.REDSTONE, 1));
		inv2.setItem(33, new ItemStack(Material.DIAMOND, 1));
		inv2.setItem(34, new ItemStack(Material.REDSTONE, 1));
		
		inv2.setItem(41, new ItemStack(Material.SAND, 1));
		inv2.setItem(42, new ItemStack(Material.REDSTONE, 1));
		inv2.setItem(43, new ItemStack(Material.SAND, 1));
		
		inv2.setItem(45, previous());
		
		
		
	}
	
	public static ItemStack next(){
		ItemStack is = new ItemStack(Material.BED, 1);
		ItemMeta im = is.getItemMeta();
		im.setDisplayName(ChatUtil.fixColors("&eNASTEPNA STRONA"));
		is.setItemMeta(im);
		return is;
	}
	
	public static ItemStack previous(){
		ItemStack is = new ItemStack(Material.BED, 1);
		ItemMeta im = is.getItemMeta();
		im.setDisplayName(ChatUtil.fixColors("&ePOPRZEDNIA STRONA"));
		is.setItemMeta(im);
		return is;
	}

}
