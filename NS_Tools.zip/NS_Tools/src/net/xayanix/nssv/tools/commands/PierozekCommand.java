package net.xayanix.nssv.tools.commands;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.xayanix.nssv.tools.utils.ChatUtil;

public class PierozekCommand implements CommandExecutor{

	@SuppressWarnings("deprecation")
	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		if(!arg0.hasPermission("admin")) return false;
		if(arg3.length < 2){
			ChatUtil.sendMessage(arg0, "&8#&c Uzycie:&7 /pierozek <nick/*> <ilosc>");
			return false;
		}
		String k = arg3[0];
		if(k.equalsIgnoreCase("*")){
			for(Player p : Bukkit.getOnlinePlayers()){
				givePierozek(p, Integer.valueOf(arg3[1]));
			}
			Bukkit.broadcastMessage(ChatUtil.fixColors("&8#&6 Wszyscy otrzymali magiczny pierozek!"));
			return true;
		}
		Player player = Bukkit.getPlayer(k);
		if(player == null){
			arg0.sendMessage(ChatUtil.fixColors("&8#&6 Gracz jest offline."));
			return false;
		}
		givePierozek(player, Integer.valueOf(arg3[1]));
		ChatUtil.sendMessage(arg0, "&8#&a Gracz otrzymal pierozek.");
		
		return true;
	}
	
	public static void givePierozek(Player player, int ilosc){
		ItemStack is = new ItemStack(Material.DRAGON_EGG, ilosc);
		ItemMeta im = is.getItemMeta();
		im.setDisplayName(ChatUtil.fixColors("&aPIEROZEK"));
		is.setItemMeta(im);
		player.getInventory().addItem(is);
	}

}
