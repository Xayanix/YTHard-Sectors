package net.xayanix.nssv.tools.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import net.xayanix.nssv.tools.utils.ChatUtil;

public class EnderchestCommand implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		if(!arg0.hasPermission("vip")){
			ChatUtil.sendMessage(arg0, "&8#&c Nie posiadasz uprawnien.");
			return false;
		}
		((Player) arg0).openInventory(((Player) arg0).getEnderChest());
		return true;
	}

}
