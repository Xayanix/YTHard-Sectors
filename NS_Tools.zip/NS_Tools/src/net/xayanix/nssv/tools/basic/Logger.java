package net.xayanix.nssv.tools.basic;

public class Logger {
	public static void info(String info){
		System.out.println("[NS_Tools] " + info);
	}
	
	public static void warn(String warn){
		System.err.println("[NS_Tools] " + warn);
	}
}
