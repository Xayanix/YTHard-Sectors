package net.xayanix.nssv.tools.basic;

public class Settings {
	
	public static String mysqlhost;
	public static int mysqlport;
	public static String mysqluser;
	public static String mysqlpass;
	public static String mysqldb;

}
