package net.xayanix.nssv.tools.basic;

import org.bukkit.Bukkit;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import net.xayanix.nssv.tools.commands.CobbleCommand;
import net.xayanix.nssv.tools.commands.CraftCommand;
import net.xayanix.nssv.tools.commands.DropCommand;
import net.xayanix.nssv.tools.commands.EnderchestCommand;
import net.xayanix.nssv.tools.commands.HelpCommand;
import net.xayanix.nssv.tools.commands.PierozekCommand;
import net.xayanix.nssv.tools.commands.SpawnCommand;
import net.xayanix.nssv.tools.commands.SyncCommand;
import net.xayanix.nssv.tools.commands.TsCommand;
import net.xayanix.nssv.tools.commands.TwCommand;
import net.xayanix.nssv.tools.commands.VipCommand;
import net.xayanix.nssv.tools.commands.WorkbenchCommand;
import net.xayanix.nssv.tools.commands.WwwCommand;
import net.xayanix.nssv.tools.commands.YtCommand;
import net.xayanix.nssv.tools.drop.Drop;
import net.xayanix.nssv.tools.listeners.BlockBreakListener;
import net.xayanix.nssv.tools.listeners.BlockPlaceListener;
import net.xayanix.nssv.tools.listeners.EntityExplodeListener;
import net.xayanix.nssv.tools.listeners.GamemodeChangeListener;
import net.xayanix.nssv.tools.listeners.InventoryClickListener;
import net.xayanix.nssv.tools.listeners.PlayerDropItemListener;
import net.xayanix.nssv.tools.listeners.PlayerInteractListener;
import net.xayanix.nssv.tools.listeners.PlayerLoginListener;
import net.xayanix.nssv.tools.listeners.WeatherChangeListener;
import net.xayanix.nssv.tools.managers.ConfigurationManager;
import net.xayanix.nssv.tools.managers.DatabaseManager;
import net.xayanix.nssv.tools.task.CommandsTask;
import net.xayanix.nssv.tools.utils.RecipeUtil;

public class Main extends JavaPlugin{
	
	private static Main instance;
	private static String sector;
	
	public void onEnable(){
		sector = Bukkit.getServerName();
		instance = this;
		PluginManager pm = Bukkit.getPluginManager();
		
		pm.registerEvents(new BlockBreakListener(), this);
		pm.registerEvents(new BlockPlaceListener(), this);
		pm.registerEvents(new InventoryClickListener(), this);
		pm.registerEvents(new PlayerInteractListener(), this);
		pm.registerEvents(new WeatherChangeListener(), this);
		pm.registerEvents(new PlayerLoginListener(), this);
		pm.registerEvents(new PlayerDropItemListener(), this);
		pm.registerEvents(new GamemodeChangeListener(), this);
		pm.registerEvents(new EntityExplodeListener(), this);
		
		getCommand("sync").setExecutor(new SyncCommand());
		getCommand("spawn").setExecutor(new SpawnCommand());
		getCommand("help").setExecutor(new HelpCommand());
		getCommand("vip").setExecutor(new VipCommand());
		getCommand("ts3").setExecutor(new TsCommand());
		getCommand("www").setExecutor(new WwwCommand());
		getCommand("yt").setExecutor(new YtCommand());
		getCommand("tw").setExecutor(new TwCommand());
		getCommand("craft").setExecutor(new CraftCommand());
		getCommand("drop").setExecutor(new DropCommand());
		getCommand("enderchest").setExecutor(new EnderchestCommand());
		getCommand("workbench").setExecutor(new WorkbenchCommand());
		getCommand("pierozek").setExecutor(new PierozekCommand());
		getCommand("cobble").setExecutor(new CobbleCommand());
		
		
		ConfigurationManager.defaultConfiguration();
		ConfigurationManager.loadConfiguration();
		DatabaseManager.connect();
		CommandsTask.truncate();
		Drop.loadDrops();
		
		RecipeUtil.register();
		CraftCommand.craftInventoryPrepare();
		DropCommand.dropInventoryPrepare();
		
		
		new CommandsTask().start();
		
		Logger.info("Uruchomiono.");
	}
	
	public void onDisable(){
		Logger.info("Wylaczono.");
	}
	
	
	public static Main getInstance(){
		return instance;
	}
	
	public static String getSector(){
		return sector;
	}

}
