package net.xayanix.nssv.tools.drop;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class Drop {
	
	private ItemStack drop;
	private Double chance;
	
	public static List<Drop> drops = new ArrayList<Drop>();
	private static void addDrop(Material m, Double chance){
		Drop drop = new Drop();
		drop.setItemStack(m);
		drop.setChance(chance);
		drops.add(drop);
	}
	
	public static void loadDrops(){
		addDrop(Material.DIAMOND, 2.5);
		addDrop(Material.IRON_INGOT, 4.0);
		addDrop(Material.GOLD_INGOT, 3.5);
		addDrop(Material.COAL, 5.0);
		addDrop(Material.REDSTONE, 5.0);
		addDrop(Material.LAPIS_ORE, 5.0);
		addDrop(Material.APPLE, 0.5);
		addDrop(Material.OBSIDIAN, 1.5);
		addDrop(Material.TNT, 0.25);
		addDrop(Material.EMERALD, 1.5);
		addDrop(Material.BOOK, 2.2);
		addDrop(Material.ENDER_PEARL, 0.1);
	}
	
	
	public void setItemStack(Material m){
		this.drop = new ItemStack(m, 1);
	}
	
	public void setChance(Double chance){
		this.chance = chance;
	}
	
	public ItemStack getItem(){
		return this.drop;
	}
	
	public Double getChance(){
		return this.chance;
	}

}
