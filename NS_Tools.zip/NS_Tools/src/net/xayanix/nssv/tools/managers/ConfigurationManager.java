package net.xayanix.nssv.tools.managers;

import org.bukkit.configuration.file.FileConfiguration;

import net.xayanix.nssv.tools.basic.Logger;
import net.xayanix.nssv.tools.basic.Main;
import net.xayanix.nssv.tools.basic.Settings;

public class ConfigurationManager {

	private static FileConfiguration fc = Main.getInstance().getConfig();
	
	public static void defaultConfiguration(){

		fc.addDefault("options.mysql.host", "localhost");
		fc.addDefault("options.mysql.port", 3306);
		fc.addDefault("options.mysql.user", "root");
		fc.addDefault("options.mysql.db", "sektory");
		fc.addDefault("options.mysql.pass", "pass");
		
		fc.options().copyDefaults(true);
		Main.getInstance().saveConfig();
	}

	public static void loadConfiguration(){
		
		Settings.mysqlhost = fc.getString("options.mysql.host");
		Settings.mysqlport = fc.getInt("options.mysql.port");
		Settings.mysqluser = fc.getString("options.mysql.user");
		Settings.mysqlpass = fc.getString("options.mysql.pass");
		Settings.mysqldb = fc.getString("options.mysql.db");
		
		Logger.info("Configuration loaded.");
	}
	
}
