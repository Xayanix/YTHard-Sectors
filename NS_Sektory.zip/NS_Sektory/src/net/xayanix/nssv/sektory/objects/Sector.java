package net.xayanix.nssv.sektory.objects;

import org.bukkit.Location;

import net.xayanix.nssv.sektory.basic.Settings;

public class Sector {
	
	private int id;
	private Location center;
	private String connectId;
	private String tps = "20.0";
	private int playerCount = 0;
	private int maxZ = Settings.sectorSize;
	private int maxX = Settings.sectorSize;
	
	public void setTps(String tps){
		this.tps = tps;
	}
	
	public void setPlayerCount(int count){
		this.playerCount = count;
	}
	
	public void setId(int id){
		this.id = id;
	}
	
	public void setCenter(Location center){
		this.center = center;
	}
	
	public void setBungeeId(String connectId){
		this.connectId = connectId;
	}
	
	
	public int getId(){
		return this.id;
	}
	
	public Location getCenter(){
		return this.center;
	}
	
	public String getConnectId(){
		return this.connectId;
	}
	
	public int getPlayerCount(){
		return this.playerCount;
	}
	
	public String getTps(){
		return this.tps;
	}
	
	public int getMaxX(){
		return this.maxX;
	}
	
	public int getMaxZ(){
		return this.maxZ;
	}
	
	public void setMaxX(int f){
		this.maxX = f;
	}
	
	public void setMaxZ(int f){
		this.maxZ = f;
	}
	
	

}
