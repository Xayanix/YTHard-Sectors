package net.xayanix.nssv.sektory.objects;

import org.bukkit.Location;

public class User {

	private Boolean readyToChangeServer = false;
	private Location lastSuccessLocation;
	private Long joinTime = 0L;
	private Long lastSave = 0L;
	private Integer antyLogout = 0;
	private int version = 5;
	private Boolean immuneNextFall = true;
	
	public Boolean needImmuneNextFall(){
		return this.immuneNextFall;
	}
	
	public void setImmuneNextFall(Boolean v){
		this.immuneNextFall = v;
	}
	
	public int getLogout(){
		return this.antyLogout;
	}
	
	public void decreaseLogout(){
		this.antyLogout = this.antyLogout - 1;
	}
	
	public Long getJoinTime(){
		return this.joinTime;
	}
	
	public Location getLocation(){
		return this.lastSuccessLocation;
	}
	
	public Boolean isReady(){
		return this.readyToChangeServer;
	}
	
	public void setLocation(Location value){
		this.lastSuccessLocation = value;
	}
	
	public void setReady(Boolean ready){
		this.readyToChangeServer = ready;
	}
	
	public void setJoined(){
		this.joinTime = System.currentTimeMillis() + 3000;
	}

	public void hit(){
		this.antyLogout = 20;
	}
	
	public void hit(int hit){
		this.antyLogout = hit;
	}
	
	public void resetLogout(){
		this.antyLogout = 0;
	}
	
	public int getVersion(){
		return this.version;
	}
	
	public void setVersion(int version){
		this.version = version;
	}
	
	public Boolean lastSave(){
		if(this.lastSave > System.currentTimeMillis()) return false;
		this.lastSave = System.currentTimeMillis() + 1500;
		return true;
	}
	
}
