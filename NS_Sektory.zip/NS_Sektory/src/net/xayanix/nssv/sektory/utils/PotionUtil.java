package net.xayanix.nssv.sektory.utils;

import java.util.ArrayList;
import java.util.Collection;

import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PotionUtil {

	  public static Collection<PotionEffect> deserializePotionEffects(String potionEffectString) {
	        java.util.Collection<PotionEffect> rtrn = new ArrayList<PotionEffect>();
	        potionEffectString = potionEffectString.replace(";", "");
	        for (String serializedEffect : potionEffectString.split("e@")) {
	            String effectName = serializedEffect.split(":d@")[0];
	            String effectDuration = "";
	            String effectAmplifier = "";
	            for (String serializedEffectSplit : serializedEffect.split(":d@")) {
	                if (serializedEffectSplit.equals(effectName) == false) {
	                    String[] getDurAndAmp = serializedEffectSplit.split(":a@");
	                    for (int i = 0; i < getDurAndAmp.length; i++) {
	                        if (i == 0) {
	                            if (getDurAndAmp[i].equals("") == false) {
	                                effectDuration = getDurAndAmp[i];
	                            }
	                        }
	                        if (i == 1) {
	                            if (getDurAndAmp[i].equals("") == false) {
	                                effectAmplifier = getDurAndAmp[i];
	                            }
	                        }
	                    }
	                }
	            }
	            if (effectName.equals("") == false && effectDuration.equals("") == false && effectAmplifier.equals("") == false) {
	                rtrn.add(new PotionEffect(PotionEffectType.getByName(effectName), Integer.valueOf(effectDuration), Integer.valueOf(effectAmplifier)));
	            }
	        }
	        return rtrn;
	    }

	    public static String serializePotionEffects(Player player) {
	        java.util.Collection<PotionEffect> effects = player.getActivePotionEffects();
	        String rtrn = ";";
	        for (PotionEffect effect : effects) {
	            String effectName = effect.getType().getName();
	            int duration = effect.getDuration();
	            int amplify = effect.getAmplifier();
	            rtrn += "e@" + effectName + ":d@" + duration + ":a@" + amplify;
	        }
	        rtrn += ";";
	        return rtrn;
	    }
	
}
