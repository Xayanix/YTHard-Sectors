package net.xayanix.nssv.sektory.utils;

import org.bukkit.Bukkit;

public class SectorUtil {

	public static void broadcastSectors(String sector, String wiadomosc){
		Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "sync console all gab " + sector + " " + wiadomosc);
	}
	
}
