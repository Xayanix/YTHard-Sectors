package net.xayanix.nssv.sektory.utils;

import org.bukkit.entity.Player;

import net.xayanix.nssv.sektory.api.BarAPI;
import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.User;

public class BarUtil {
	
	public static void sendBar(Player p, String wiadomosc, float percent, int ticks){
		User user = UserManager.getUser(p);
		if(user.getVersion() != 47){
			BarAPI.set(p, wiadomosc, percent, ticks);
		}
	}

}
