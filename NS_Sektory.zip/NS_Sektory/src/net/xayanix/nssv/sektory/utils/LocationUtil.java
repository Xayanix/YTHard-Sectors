package net.xayanix.nssv.sektory.utils;

import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.sektory.objects.Sector;

public class LocationUtil {
	
	public static Boolean isSameLocation(Location loc1, Location loc2){
		if(Math.floor(loc1.getX()) == Math.floor(loc2.getX()) && Math.floor(loc1.getZ()) == Math.floor(loc2.getZ())){
			return true;
		}
		return false;
	}
	
	public static Location getLocationFromXZ(int x, int z){
		return new Location(Bukkit.getWorld(Settings.world), x, 0, z);
	}
	
	public static int distance(int a, int b){
		int distance = a - b;
		if(distance < 0) distance = distance * -1;
		return distance;
	}
	
	public static int naturalize(int i){
		if(i < 0) i = i * -1;
		return i;
	}
	
	public static Location getRandomCords() {
		Location loc = new Location(Bukkit.getWorlds().get(0), RandomUtil.getRandInt(-4500, 4500), 0, RandomUtil.getRandInt(-4500, 4500));
		return loc;
	}
	
	public static Location getRandomCords(Sector sector) {
		Location loc = new Location(Bukkit.getWorlds().get(0), RandomUtil.getRandInt((int) (sector.getCenter().getX() - Settings.sectorSize), (int) (sector.getCenter().getZ() + Settings.sectorSize)), 0, RandomUtil.getRandInt((int) (sector.getCenter().getZ() - Settings.sectorSize), (int) (sector.getCenter().getZ() + Settings.sectorSize)));
		return loc;
	}
	
	public static Location getValidRandomCords(Sector sector) {
		Location loc = getRandomCords(sector);
		loc.setY(loc.getWorld().getHighestBlockAt(loc).getLocation().getY() + 2);
		return loc;
	}
	
	@SuppressWarnings("deprecation")
	public static void knockLineBorder(Player p) {
		Location l = p.getLocation().subtract(Main.currentSector.getCenter());
		double distance = p.getLocation().distance(Main.currentSector.getCenter());
		Vector v = l.toVector().add(new Vector(0, 5, 0)).multiply(1.25 / distance);
		p.setVelocity(v.multiply(-1.5));
		p.playEffect(p.getLocation(), Effect.MOBSPAWNER_FLAMES, 10);
	}
	
	public static void teleportMainThread(Player p, Location loc){
		Bukkit.getServer().getScheduler().runTaskLater(Main.getInstance(), new Runnable() { 
			public void run() { 
				p.teleport(loc);
				//if(!Main.currentSector.getConnectId().equalsIgnoreCase(SectorManager.getSector(loc).getConnectId())){
				//	SectorConnectTask.toConnect.add(p.getName());
				//}
				// TO DO: Sector reanalyze?
			}
		}, 1);
	}

}
