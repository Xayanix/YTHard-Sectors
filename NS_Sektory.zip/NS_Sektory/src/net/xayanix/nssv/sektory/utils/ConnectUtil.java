package net.xayanix.nssv.sektory.utils;

import java.io.DataOutputStream;
import java.io.IOException;

import org.bukkit.entity.Player;

import net.minecraft.util.org.apache.commons.io.output.ByteArrayOutputStream;
import net.xayanix.nssv.sektory.basic.Logger;
import net.xayanix.nssv.sektory.basic.Main;

public class ConnectUtil {
	
	private static DataOutputStream out;

	public static void sendPlayer(Player player, String server){

		ByteArrayOutputStream b = new ByteArrayOutputStream();
		out = new DataOutputStream(b);
		try {
			out.writeUTF("Connect");
			out.writeUTF(server); 
		} catch (IOException localIOException) {
			Logger.warn("Exception while sending " + player.getName() + " to " + server + ".");
		}
		player.sendPluginMessage(Main.getInstance(), "BungeeCord", b.toByteArray());
	}
	
}
