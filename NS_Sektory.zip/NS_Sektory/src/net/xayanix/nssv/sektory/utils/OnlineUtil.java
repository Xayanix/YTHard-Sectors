package net.xayanix.nssv.sektory.utils;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.managers.DatabaseManager;

public class OnlineUtil {
	
	public static void markAsOnline(final Player p){
		Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), new Runnable() {
			@Override
			public void run() {
				DatabaseManager.executeQuery("INSERT INTO `sector_players` (`id`, `sektor`, `player`) VALUES (NULL, '" + Main.getSector() + "', '" + p.getName() + "');");
			}
		});
	}
	
	public static void markAsOffline(final Player p){
		Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), new Runnable() {
			@Override
			public void run() {
				DatabaseManager.executeQuery("DELETE FROM `sector_players` WHERE `sektor` = '" + Main.getSector() + "' AND `player` = '" + p.getName() + "'");
			}
		});
	}
	
	public static void kickAll(){
		Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), new Runnable() {
			@Override
			public void run() {
				DatabaseManager.executeQuery("DELETE FROM `sector_players` WHERE `sektor` = '" + Main.getSector() + "'");
			}
		});
	}

}
