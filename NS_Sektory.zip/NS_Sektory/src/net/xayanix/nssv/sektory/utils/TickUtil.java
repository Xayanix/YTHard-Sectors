package net.xayanix.nssv.sektory.utils;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.managers.DatabaseManager;
import net.xayanix.nssv.sektory.managers.SectorManager;
import net.xayanix.nssv.sektory.objects.Sector;
import net.xayanix.nssv.sektory.runnable.TickTask;

public class TickUtil {

	public static void uploadTps(){
		Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), new Runnable() {
			@SuppressWarnings("deprecation")
			@Override
			public void run() {
				DatabaseManager.executeQuery("DELETE FROM `sector_data` WHERE `sektor` = '" + Main.getSector() + "'");
				DatabaseManager.executeQuery("INSERT INTO `sector_data` (`id`, `sektor`, `tps`, `players`) VALUES (NULL, '" + Main.getSector() + "', '" + TickTask.getTPS() + "', '" + Bukkit.getOnlinePlayers().length + "');");
			}});
	}
	
	public static void downloadTps(){
		Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), new Runnable() {
			@Override
			public void run() {
				try {
					ResultSet rs = DatabaseManager.getQueryResult("SELECT * FROM `sector_data`");
					while(rs.next()){
						Sector sector = SectorManager.getSector(rs.getString("sektor"));
						sector.setTps(rs.getString("tps"));
						sector.setPlayerCount(rs.getInt("players"));
					}
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}});
		
	}
	
	public static void downloadTps(final Player p){
		Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), new Runnable() {
			@Override
			public void run() {
				try {
					ResultSet rs = DatabaseManager.getQueryResult("SELECT * FROM `sector_data`");
					while(rs.next()){
						Sector sector = SectorManager.getSector(rs.getString("sektor"));
						if(sector != null){
							sector.setTps(rs.getString("tps"));
							sector.setPlayerCount(rs.getInt("players"));
						}	
					}
					for(Sector s : SectorManager.getSectors()){
						ChatUtil.sendMessage(p, "&8�&7 SEKTOR " + s.getConnectId() + ": " + tpsColor(s.getTps()) + " TPS&7, " + s.getPlayerCount() + " GRACZY");
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}});
		
	}
	
	public static String tpsColor(String tps){
		tps = tps.replace(",", ".");
		Double tpsd = Double.valueOf(tps);
		String color = "&c";
		if(tpsd >= 15) color = "&e";
		if(tpsd >= 18) color = "&a";
		return ChatUtil.fixColors(color + tps);
	}
	
}
