package net.xayanix.nssv.sektory.runnable;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import net.xayanix.nssv.sektory.api.BarAPI;
import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.User;
import net.xayanix.nssv.sektory.utils.ChatUtil;

public class CombatTask implements Runnable{

	@SuppressWarnings("deprecation")
	@Override
	public void run() {
		for(Player player : Bukkit.getOnlinePlayers()){
			User user = UserManager.getUser(player);
			if(user.getLogout() > 0){
				if(user.getLogout() == 1){
					BarAPI.remove(player);
					user.hit(0);
				}
				else {
					float procent = ((float) user.getLogout()) / 20;
					BarAPI.set(player, ChatUtil.fixColors("&cANTYLOGOUT (" + user.getLogout() + " sek.)"), procent, 0);
				}
				user.decreaseLogout();
			}
		}
	}
	
	public void start(){
		Bukkit.getScheduler().runTaskTimerAsynchronously(Main.getInstance(), this, 0, 20);
	}

}
