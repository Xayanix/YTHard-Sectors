package net.xayanix.nssv.sektory.runnable;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.managers.SectorManager;
import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.Sector;
import net.xayanix.nssv.sektory.objects.User;
import net.xayanix.nssv.sektory.utils.ConnectUtil;

public class SectorConnectTask implements Runnable{

	public static List<String> toConnect = new ArrayList<String>();
	
	@Override
	public void run() {
		List<String> toConnectcp = new ArrayList<String>(toConnect);
		for(String playern : toConnectcp){
			Player player = Bukkit.getPlayer(playern);
			if(player != null){
				Sector sector = SectorManager.getSector(player);
				User user = UserManager.getUser(player);
				if(sector != Main.currentSector && user.getLogout() <= 0){
					ConnectUtil.sendPlayer(player, sector.getConnectId());
				}
			}
			else toConnect.remove(playern);
			
		}
	}
	
	public void start(){
		Bukkit.getScheduler().runTaskTimerAsynchronously(Main.getInstance(), this, 25, 25);
	}

}
