package net.xayanix.nssv.sektory.runnable;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import net.xayanix.nssv.sektory.api.BarAPI;
import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.sektory.managers.SectorManager;
import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.User;
import net.xayanix.nssv.sektory.utils.ChatUtil;

public class BarTask implements Runnable{

	public static List<String> bar_players = new ArrayList<String>();
	
	@Override
	public void run() {
		List<String> bar_playerscp = new ArrayList<String>(bar_players);
		for(String playern : bar_playerscp){
			Player player = Bukkit.getPlayer(playern);
			if(player != null){
				if(!SectorManager.getSector(player).getConnectId().equalsIgnoreCase(Main.getSector())){
					if(SectorConnectTask.toConnect.contains(playern)){
						BarAPI.set(player, ChatUtil.fixColors("&cPRZENOSZENIE NA SEKTOR:&7 " + Main.getSector() + " -> " + SectorManager.getSector(player).getConnectId() + ")"), 1, 0);
					}
				}
				else{
					User user = UserManager.getUser(player);
						
					if(user.getLogout() == 0){
						if(SectorManager.isNearNextSector(player.getLocation(), 100)) {
							float odleglosc = (float) SectorManager.toNextSector(player.getLocation());
							float procent = odleglosc / 100;
							if(Settings.spawn.distance(player.getLocation()) > Settings.sectorSize*2)BarAPI.set(player, ChatUtil.fixColors("&7Granica swiata: &c" + odleglosc + " KRATEK"), (float) procent, 0);
							else BarAPI.set(player, ChatUtil.fixColors("&7Granica sektora: &c" + odleglosc + " KRATEK"), (float) procent, 0);
						}
						else {
							bar_players.remove(player);
							user.resetLogout();
						}
					}
					
				}
			}
			else bar_players.remove(playern);
		}
	}
	
	public void start(){
		Bukkit.getScheduler().runTaskTimerAsynchronously(Main.getInstance(), this, 0, 20);
	}

}
