package net.xayanix.nssv.sektory.listeners;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import net.xayanix.nssv.sektory.api.BarAPI;
import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.sektory.managers.SectorManager;
import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.Sector;
import net.xayanix.nssv.sektory.objects.User;
import net.xayanix.nssv.sektory.runnable.BarTask;
import net.xayanix.nssv.sektory.runnable.SectorConnectTask;
import net.xayanix.nssv.sektory.utils.ChatUtil;
import net.xayanix.nssv.sektory.utils.LocationUtil;

public class PlayerMoveListener implements Listener{
	
	@EventHandler
	public void onMove(PlayerMoveEvent event){
		Location from = event.getFrom();
		Location to = event.getTo();
		if(LocationUtil.isSameLocation(from, to)) return;
		
		Player player = event.getPlayer();
		Sector sector = SectorManager.getSector(player);
		User user = UserManager.getUser(player);
		
		if(user.getJoinTime() > System.currentTimeMillis()){
			return;
		}
		if(to.getX() > Settings.border || to.getX() < -Settings.border || to.getZ() > Settings.border || to.getZ() < -Settings.border){
			player.teleport(user.getLocation());
			ChatUtil.sendMessage(player, "&8# &cKoniec swiata.");
			LocationUtil.knockLineBorder(player);
			return;
		}
		user.setLocation(from);
		
		if(Main.currentSector != sector && !sector.getConnectId().equalsIgnoreCase("BORDER") && !sector.getConnectId().equalsIgnoreCase("POZA_MAPA")){
			if(user.getLogout() > 0){
				LocationUtil.knockLineBorder(player);
				ChatUtil.sendMessage(player, "&8#&c Nie zmieniaj sektora podczas walki.");
				return;
			}
			if(!SectorConnectTask.toConnect.contains(player.getName())){
				UserManager.sendPlayerInfo(player);
				SectorConnectTask.toConnect.add(player.getName());
				user.setReady(true);
			}
		}
		else if(SectorConnectTask.toConnect.contains(player.getName())){
			SectorConnectTask.toConnect.remove(player.getName());
		}
		
		if(SectorManager.isNearNextSector(from, 100)){
			if(!user.isReady()){
				user.setReady(true);
				BarTask.bar_players.add(player.getName());
			}
		}
		else if(user.isReady()){
			BarTask.bar_players.remove(player.getName());
			user.setReady(false);
			BarAPI.remove(player);
		}
		
	}

}
