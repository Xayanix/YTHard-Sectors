package net.xayanix.nssv.sektory.listeners;

import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.User;
import net.xayanix.nssv.sektory.utils.ChatUtil;
import net.xayanix.nssv.sektory.utils.InventoryUtil;
import net.xayanix.nssv.sektory.utils.OnlineUtil;

public class PlayerJoinListener implements Listener{
	
	@EventHandler
	public void onJoin(PlayerJoinEvent event){
		
		final Player player = event.getPlayer();
		event.setJoinMessage(null);
		
		User user = UserManager.createUser(player);
		user.setJoined();
		user.setReady(false);
		user.setVersion(((CraftPlayer) player).getHandle().playerConnection.networkManager.getVersion());
		user.setImmuneNextFall(true);
		
		OnlineUtil.markAsOnline(player);
		
		InventoryUtil.clearInventory(player);
		player.getEnderChest().clear();
		
		ChatUtil.sendMessage(player, "&8# &aPOLACZONO Z SEKTOREM:&7 " + Main.currentSector.getConnectId());
		player.teleport(player.getLocation().add(0.0, 500.0, 0.0));
		
		Bukkit.getServer().getScheduler().runTaskLater(Main.getInstance(), new Runnable() {
			public void run() {
				if(!player.isOnline()) return;
				if(player.isDead()) player.spigot().respawn();
				UserManager.downloadPlayerInfo(player);
				
			}}, 22);
	}

}
