package net.xayanix.nssv.sektory.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.User;

public class PlayerDeathListener implements Listener{
	
	@EventHandler
	public void onDeath(PlayerDeathEvent event){
		Player player = event.getEntity();
		User user = UserManager.getUser(player);
		user.setReady(true);
		user.resetLogout();
		UserManager.sendPlayerInfo(player, Settings.spawn);
	}

}
