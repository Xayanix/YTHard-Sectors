package net.xayanix.nssv.sektory.listeners;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;

import net.xayanix.nssv.sektory.managers.SectorManager;
import net.xayanix.nssv.sektory.utils.ChatUtil;

public class PlayerDropItemListener implements Listener{
	
	@EventHandler
	public void onInteract(PlayerDropItemEvent event){
		if(SectorManager.isNearNextSector(event.getPlayer().getLocation(), 20)){
			event.setCancelled(true);
			event.getPlayer().sendMessage(ChatUtil.fixColors("&8#&c Jestes zbyt blisko granicy sektora."));
		}
		
	}

}
