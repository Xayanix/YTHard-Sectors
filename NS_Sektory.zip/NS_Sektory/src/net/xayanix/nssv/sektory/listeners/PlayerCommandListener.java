package net.xayanix.nssv.sektory.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.User;
import net.xayanix.nssv.sektory.utils.ChatUtil;

public class PlayerCommandListener implements Listener{
	
	@EventHandler
	public void onCommand(PlayerCommandPreprocessEvent event){
		Player player = event.getPlayer();
		User user = UserManager.getUser(player);
		
		if(user.getLogout() > 0 && !player.hasPermission("admin")){
			ChatUtil.sendMessage(player, "&8#&c Jestes w trakcie walki.");
			event.setCancelled(true);
		}
		
	}

}
