package net.xayanix.nssv.sektory.listeners;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.sektory.managers.SectorManager;
import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.Sector;
import net.xayanix.nssv.sektory.objects.User;
import net.xayanix.nssv.sektory.utils.ChatUtil;
import net.xayanix.nssv.sektory.utils.ConnectUtil;

public class PlayerTeleportListener implements Listener{

	@EventHandler
	public void onTeleport(PlayerTeleportEvent event){
		Location to = event.getTo();
		
		Player player = event.getPlayer();
		User user = UserManager.getUser(player);
		Sector sector = SectorManager.getSector(to);
		
		if(user.getLogout() > 0){
			if(event.getCause() != TeleportCause.ENDER_PEARL){
				ChatUtil.sendMessage(player, "&8#&c Jestes w trakcie walki, teleportacja przerwana.");
				event.setCancelled(true);
				return;
			}
			else if(event.getCause() == TeleportCause.ENDER_PEARL){
				if(sector != Main.currentSector){
					ChatUtil.sendMessage(player, "&8#&c Nie zmieniaj sektora podczas walki.");
					event.setCancelled(true);
					return;
				}
			}
			
		}
		
		if(to.getX() > Settings.border || to.getX() < -Settings.border || to.getZ() > Settings.border || to.getZ() < -Settings.border){
			event.setCancelled(true);
			ChatUtil.sendMessage(player, "&8# &cKoniec swiata.");
			return;
		}

		if(user.getJoinTime() < System.currentTimeMillis() && Main.currentSector != sector && !sector.getConnectId().equalsIgnoreCase("BORDER") && !sector.getConnectId().equalsIgnoreCase("POZA_MAPA")){
			UserManager.sendPlayerInfo(player, to);
			ConnectUtil.sendPlayer(player, sector.getConnectId());
			user.setJoined();
			user.lastSave();
		}
	}
	
}
