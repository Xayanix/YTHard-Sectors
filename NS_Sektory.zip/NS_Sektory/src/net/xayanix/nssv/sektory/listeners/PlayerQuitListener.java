package net.xayanix.nssv.sektory.listeners;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.User;
import net.xayanix.nssv.sektory.runnable.BarTask;
import net.xayanix.nssv.sektory.runnable.SectorConnectTask;
import net.xayanix.nssv.sektory.utils.ChatUtil;
import net.xayanix.nssv.sektory.utils.InventoryUtil;
import net.xayanix.nssv.sektory.utils.OnlineUtil;
import net.xayanix.nssv.sektory.utils.SectorUtil;

public class PlayerQuitListener implements Listener{

	@SuppressWarnings("deprecation")
	@EventHandler
	public void onQuit(PlayerQuitEvent event){
		Player player = event.getPlayer();
		User user = UserManager.getUser(player);
		event.setQuitMessage(null);
		
		if(BarTask.bar_players.contains(player.getName())){
			BarTask.bar_players.remove(player.getName());
		}
		
		if(SectorConnectTask.toConnect.contains(player.getName())){
			SectorConnectTask.toConnect.remove(player.getName());
		}
		
		OnlineUtil.markAsOffline(player);
		
		if(user.lastSave()){
			UserManager.sendPlayerInfo(player);
		}
		
		if(user.getLogout() > 0 && Settings.logout){
			user.resetLogout();
			Bukkit.broadcastMessage(ChatUtil.fixColors("&8# &6" + player.getName() + "&7 wylogowal sie podczas walki."));
			SectorUtil.broadcastSectors(Main.getSector(), ChatUtil.fixColors("&8# &6" + player.getName() + "&7 wylogowal sie podczas walki."));
			player.damage(999);
			InventoryUtil.clearInventory(player);
			UserManager.sendPlayerInfo(player, Settings.spawn);
			return;
		}
	}
	
}
