package net.xayanix.nssv.sektory.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.managers.SectorManager;
import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.User;
import net.xayanix.nssv.sektory.utils.ChatUtil;

public class EntityDamageListener implements Listener{
	
	@EventHandler
	public void onDamage(EntityDamageEvent event){
		if(event.getEntity() instanceof Player){
			Player player = (Player) event.getEntity();
			User user = UserManager.getUser(player);
			
			if(event.getCause() == DamageCause.FALL && user.needImmuneNextFall()){
				event.setCancelled(true);
				user.setImmuneNextFall(false);
				ChatUtil.sendMessage(player, "&8#&a Upadek zostal zabsorbowany.");
			}
			
			if(user.getJoinTime() > System.currentTimeMillis() && user.getLogout() == 0){
				event.setCancelled(true);
			}
			
			if(!Main.getSector().equalsIgnoreCase(SectorManager.getSector(player).getConnectId())){
				event.setCancelled(true);
			}
			
		}
	}

}
