package net.xayanix.nssv.sektory.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.User;

public class EntityDamageByEntityListener implements Listener{
	
	@EventHandler(priority = EventPriority.HIGHEST)
	public void onDamage(EntityDamageByEntityEvent event){
		if(event.isCancelled()) return;
		if(event.getDamager() instanceof Player && event.getEntity() instanceof Player){
			Player attacker = (Player) event.getDamager();
			Player victim = (Player) event.getEntity();
			
			User user = UserManager.getUser(attacker);
			User user2 = UserManager.getUser(victim);
			
			user.hit();
			user2.hit();
		}
		
	}

}
