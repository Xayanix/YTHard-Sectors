package net.xayanix.nssv.sektory.listeners;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import net.xayanix.nssv.sektory.managers.SectorManager;

public class PlayerInteractListener implements Listener{
	
	@EventHandler
	public void onInteract(PlayerInteractEvent event){
		Action action = event.getAction();
		
		if(action == Action.RIGHT_CLICK_BLOCK){
			if(SectorManager.isNearNextSector(event.getClickedBlock().getLocation(), 20)){
				event.setCancelled(true);
			}
		}
		
		
	}

}
