package net.xayanix.nssv.sektory.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;

import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.sektory.managers.SectorManager;
import net.xayanix.nssv.sektory.objects.Sector;
import net.xayanix.nssv.sektory.utils.ChatUtil;
import net.xayanix.nssv.sektory.utils.ConnectUtil;

public class PlayerRespawnListener implements Listener{
	
	@EventHandler
	public void onRespawn(PlayerRespawnEvent event){
		Player player = event.getPlayer();
		Sector sector = SectorManager.getSector(Settings.spawn);
		event.setRespawnLocation(Settings.spawn);
		if(sector != Main.currentSector){
			ConnectUtil.sendPlayer(player, sector.getConnectId());
			ChatUtil.sendMessage(player, " &8�&c Zginales, zostajesz odrodzony.");
		}
	}

}
