package net.xayanix.nssv.sektory.commands;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.sektory.managers.SectorManager;
import net.xayanix.nssv.sektory.managers.UserManager;
import net.xayanix.nssv.sektory.objects.Sector;
import net.xayanix.nssv.sektory.runnable.TickTask;
import net.xayanix.nssv.sektory.utils.ChatUtil;
import net.xayanix.nssv.sektory.utils.LocationUtil;
import net.xayanix.nssv.sektory.utils.TickUtil;

public class SectorCommand implements CommandExecutor{

	@SuppressWarnings("deprecation")
	@Override
	public boolean onCommand(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
		if(!arg0.hasPermission("admin")){
			ChatUtil.sendMessage(arg0, " &8�&c NS_Sectors by UnixejPL.");
			ChatUtil.sendMessage(arg0, " &8�&c &cZnajdujesz sie na sektorze:&7 " + SectorManager.getSector(((Player) arg0).getLocation()).getConnectId() + " (TPS: " + TickTask.getTPS() + ")");
			return false;
		}
		if(arg3.length == 1){
			if(arg3[0].equalsIgnoreCase("list")){
				for(Sector s : SectorManager.getSectors()){
					ChatUtil.sendMessage(arg0, "&8�&7 " + s.getConnectId() + " &7(SRODEK - X:" + s.getCenter().getX() + ", Z: " + s.getCenter().getZ() + ")");
				}
				return true;
			}
			if(arg3[0].equalsIgnoreCase("gc")){
				ChatUtil.sendMessage(arg0, "&8�&a Pobieranie danych...");
				TickUtil.downloadTps((Player) arg0);
			}
			else if(arg3[0].equalsIgnoreCase("moj")){
				ChatUtil.sendMessage(arg0, "&cZnajdujesz sie na sektorze:&7 " + SectorManager.getSector(((Player) arg0).getLocation()).getConnectId());
				return true;
			}
			else if(arg3[0].equalsIgnoreCase("test")){
				Location location = LocationUtil.getRandomCords();
				ChatUtil.sendMessage(arg0, "&cWylosowano: &7X: " + location.getX() + ", Z: " + location.getZ() + "&7. (SEKTOR: " + SectorManager.getSector(location).getConnectId() + ")");
				return true;
			}
			else if(arg3[0].equalsIgnoreCase("zapiszinfo")){
				UserManager.sendPlayerInfo((Player) arg0);
				ChatUtil.sendMessage(arg0, "&aZapisano.");
				return true;
			}
			else if(arg3[0].equalsIgnoreCase("pobierzinfo")){
				UserManager.downloadPlayerInfo((Player) arg0);
				ChatUtil.sendMessage(arg0, "&aPobrano.");
				return true;
			}
			else if(arg3[0].equalsIgnoreCase("offlogout")){
				Settings.logout = false;
				ChatUtil.sendMessage(arg0, "&aLogoutOff.");
				return true;
			}
			else if(arg3[0].equalsIgnoreCase("onlogout")){
				Settings.logout = true;
				ChatUtil.sendMessage(arg0, "&aLogoutOn.");
				return true;
			}
			else if(arg3[0].equalsIgnoreCase("saveall")){
				for(Player p : Bukkit.getOnlinePlayers()){
					UserManager.sendPlayerInfo(p);
					ChatUtil.sendMessage(p, "&8#&6 Ekwipunek gracza &7" + p.getName() + " &6zapisany.");
				}
				Bukkit.broadcastMessage(ChatUtil.fixColors("&8#&6 Administrator zapisal ekwipunek kazdego gracza z tego sektora."));
				return true;
			}
			else ChatUtil.sendMessage(arg0, "&cNieprawidlowy argument komendy.");
			return true;
		}
		ChatUtil.sendMessage(arg0, "&c/sektor list - &7wyswietla liste utworzonych sektorow.");
		ChatUtil.sendMessage(arg0, "&c/sektor gc - &7wydajnosc wszystkich sektorow.");
		ChatUtil.sendMessage(arg0, "&c/sektor moj - &7wyswietla sektor na ktorym sie znajdujesz.");
		ChatUtil.sendMessage(arg0, "&c/sektor test - &7losuje kordy i wyswietla ich sektor");
		ChatUtil.sendMessage(arg0, "&c/sektor zapiszinfo - &7zapisuje info o graczu");
		ChatUtil.sendMessage(arg0, "&c/sektor pobierzinfo - &7pobiera info o graczu");
		ChatUtil.sendMessage(arg0, "&c/sektor saveall - &7zapisuje eq wszystkich graczy");
		ChatUtil.sendMessage(arg0, "&c/sektor onlogout - &7aktywuje antylogout na sektorze");
		ChatUtil.sendMessage(arg0, "&c/sektor offantylogout - &7dezaktywuje antylogout na sektorze");
		return true;
	}

}
