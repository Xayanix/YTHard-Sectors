package net.xayanix.nssv.sektory.basic;

public class Logger {
	
	public static void info(String info){
		System.out.println("[NS_Sectors] " + info);
	}
	
	public static void warn(String warn){
		System.err.println("[NS_Sectors] " + warn);
	}

}
