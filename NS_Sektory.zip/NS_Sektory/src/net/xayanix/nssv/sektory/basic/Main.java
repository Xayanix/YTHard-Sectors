package net.xayanix.nssv.sektory.basic;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;

import net.xayanix.nssv.sektory.commands.SectorCommand;
import net.xayanix.nssv.sektory.listeners.BlockBreakListener;
import net.xayanix.nssv.sektory.listeners.BlockPlaceListener;
import net.xayanix.nssv.sektory.listeners.EntityDamageByEntityListener;
import net.xayanix.nssv.sektory.listeners.EntityDamageListener;
import net.xayanix.nssv.sektory.listeners.PlayerCommandListener;
import net.xayanix.nssv.sektory.listeners.PlayerDeathListener;
import net.xayanix.nssv.sektory.listeners.PlayerDropItemListener;
import net.xayanix.nssv.sektory.listeners.PlayerInteractListener;
import net.xayanix.nssv.sektory.listeners.PlayerJoinListener;
import net.xayanix.nssv.sektory.listeners.PlayerMoveListener;
import net.xayanix.nssv.sektory.listeners.PlayerQuitListener;
import net.xayanix.nssv.sektory.listeners.PlayerRespawnListener;
import net.xayanix.nssv.sektory.listeners.PlayerTeleportListener;
import net.xayanix.nssv.sektory.managers.ConfigurationManager;
import net.xayanix.nssv.sektory.managers.DatabaseManager;
import net.xayanix.nssv.sektory.managers.SectorManager;
import net.xayanix.nssv.sektory.objects.Sector;
import net.xayanix.nssv.sektory.runnable.BarTask;
import net.xayanix.nssv.sektory.runnable.CombatTask;
import net.xayanix.nssv.sektory.runnable.SectorConnectTask;
import net.xayanix.nssv.sektory.runnable.TickTask;
import net.xayanix.nssv.sektory.utils.OnlineUtil;

public class Main extends JavaPlugin implements PluginMessageListener{
	
	private static Main instance;
	private static String sector;
	public static Sector currentSector;
	
	public void onEnable(){
		PluginManager pm = Bukkit.getPluginManager();
		instance = this;
		sector = Bukkit.getServerName();
		
		getCommand("sektor").setExecutor(new SectorCommand());
		
		pm.registerEvents(new PlayerDeathListener(), this);
		pm.registerEvents(new BlockBreakListener(), this);
		pm.registerEvents(new BlockPlaceListener(), this);
		pm.registerEvents(new PlayerInteractListener(), this);
		pm.registerEvents(new EntityDamageByEntityListener(), this);
		pm.registerEvents(new PlayerJoinListener(), this);
		pm.registerEvents(new PlayerMoveListener(), this);
		pm.registerEvents(new PlayerTeleportListener(), this);
		pm.registerEvents(new PlayerQuitListener(), this);
		pm.registerEvents(new PlayerRespawnListener(), this);
		pm.registerEvents(new PlayerCommandListener(), this);
		pm.registerEvents(new PlayerDropItemListener(), this);
		pm.registerEvents(new EntityDamageListener(), this);
		
		ConfigurationManager.defaultConfiguration();
		ConfigurationManager.loadConfiguration();
		DatabaseManager.connect();
		OnlineUtil.kickAll();
		SectorManager.loadSectors();
		currentSector = SectorManager.getSector(sector);
		
		Bukkit.getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
		Bukkit.getMessenger().registerIncomingPluginChannel(this, "BungeeCord", this);
		
		new BarTask().start();
		new SectorConnectTask().start();
		new TickTask().start();
		new CombatTask().start();
		
		Bukkit.getWorld(Settings.world).setTime(0);
		
		Logger.info("Uruchomiono.");
	}
	
	public void onDisable(){
		Logger.info("Wylaczono.");
	}
	
	public static Main getInstance(){
		if(instance == null) instance = new Main();
		return instance;
	}
	
	public static String getSector(){
		return sector;
	}

	@Override
	public void onPluginMessageReceived(String arg0, Player arg1, byte[] arg2) {
		Logger.warn("Received PluginMessage from BungeeCord.");
	}

}
