package net.xayanix.nssv.sektory.basic;

import org.bukkit.Bukkit;
import org.bukkit.Location;

public class Settings {

	public static int sectorsAmount = 9;
	public static int sectorSize = 1000;
	public static int border = 1000;
	public static String mysqlhost;
	public static int mysqlport;
	public static String mysqluser;
	public static String mysqlpass;
	public static String mysqldb;
	public static String sectorId = "SEKTOR-";
	public static String world = "world";
	public static Boolean debug = true;
	public static Boolean logout = true;
	public static Location spawn = new Location(Bukkit.getWorld(world), 0, 75, 0);
	
}
