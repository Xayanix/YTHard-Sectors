package net.xayanix.nssv.sektory.api;

import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import net.minecraft.server.v1_7_R4.ChatSerializer;
import net.minecraft.server.v1_7_R4.IChatBaseComponent;
import net.minecraft.server.v1_7_R4.PacketPlayOutChat;
import net.xayanix.nssv.sektory.basic.Main;

public class ActionBarAPI {

	private String message;

	public ActionBarAPI(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void sendActionBar(Player player) {
		CraftPlayer p = (CraftPlayer) player;
		if (p.getHandle().playerConnection.networkManager.getVersion() != 47) {
			return;
		}
		IChatBaseComponent cbc = ChatSerializer.a("{\"text\": \"" + message + "\"}");
		PacketPlayOutChat ppoc = new PacketPlayOutChat(cbc, 2);
		p.getHandle().playerConnection.sendPacket(ppoc);
	}

	public void sendActionBar(final Player p, final int seconds) {
		new BukkitRunnable() {
			int sec = seconds;

			@Override
			public void run() {
				if (sec > 0) {
					if (p != null && p.isOnline()) {
						sendActionBar(p);
						sec--;
						return;
					}
				}
				cancel();
			}
		}.runTaskTimer(Main.getInstance(), 1, 20);
	}

	@SuppressWarnings("deprecation")
	public void broadcastActionBar() {
		for (Player p : Bukkit.getOnlinePlayers()) {
			sendActionBar(p);
		}
	}
}
