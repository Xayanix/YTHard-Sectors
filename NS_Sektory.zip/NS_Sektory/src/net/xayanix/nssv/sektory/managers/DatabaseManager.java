package net.xayanix.nssv.sektory.managers;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import net.xayanix.nssv.sektory.basic.Logger;
import net.xayanix.nssv.sektory.basic.Settings;

public class DatabaseManager {
	public static Connection con = null;
	public static boolean connected = false;
	private static String url = "jdbc:mysql://" + Settings.mysqlhost + ":" + Settings.mysqlport + "/" + Settings.mysqldb + "";

	public static void connect(){
		con = null;
		Long teraz = System.currentTimeMillis();
		Logger.info("Connecting to database");
		try{
			con = (Connection) DriverManager.getConnection(url, Settings.mysqluser, Settings.mysqlpass);
			connected = true;
			teraz = System.currentTimeMillis() - teraz;
			Logger.info("[NS_MySQL] Connection successful! (" + teraz + " ms)");
		}
		catch(Exception e){
			e.printStackTrace();
			connected = false;

		}
	}

	public static Connection getConnection(){
		if(con == null) connect();
		return con;
	}

	public static void executeQuery(String query){
		if(con == null) connect();
		try {
			Statement st = (Statement) getConnection().createStatement();
			st.executeUpdate(query);
		} catch (SQLException e) {
			connect();
			e.printStackTrace();
		}
	}

	public static ResultSet getQueryResult(String query){
		ResultSet rs = null;
		try {
			Statement st = (Statement) getConnection().createStatement();
			rs = st.executeQuery(query);
		} catch (SQLException e) {
			connect();
			e.printStackTrace();
		}
		return rs;
	}
}
