package net.xayanix.nssv.sektory.managers;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;

import net.xayanix.nssv.sektory.basic.Logger;
import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.sektory.objects.Sector;
import net.xayanix.nssv.sektory.utils.LocationUtil;

public class ConfigurationManager {

	private static FileConfiguration fc = Main.getInstance().getConfig();
	
	public static void defaultConfiguration(){
		fc.addDefault("options.sectorsAmount", 9);
		fc.addDefault("options.sectorSize", 1000);
		fc.addDefault("options.mapBorder", 1000);
		fc.addDefault("options.defaultWorld", "world");
		fc.addDefault("options.debug", true);
		fc.addDefault("options.spawn.x", 0);
		fc.addDefault("options.spawn.y", 0);
		fc.addDefault("options.spawn.z", 0);
		fc.addDefault("options.spawn.yaw", 0);
		fc.addDefault("options.spawn.pitch", 0);
		
		fc.addDefault("options.mysql.host", "localhost");
		fc.addDefault("options.mysql.port", 3306);
		fc.addDefault("options.mysql.user", "root");
		fc.addDefault("options.mysql.db", "sektory");
		fc.addDefault("options.mysql.pass", "pass");
		
		List<String> enabled = new ArrayList<String>();
		enabled.add("s1");

		fc.addDefault("sectors.enabled", enabled);
		fc.addDefault("sectors.list.s1.x", 0);
		fc.addDefault("sectors.list.s1.z", 0);
		fc.addDefault("sectors.list.s1.sectorname", "CENTER");
		fc.addDefault("sectors.list.s1.borderx", 1000);
		fc.addDefault("sectors.list.s1.borderz", 1000);
		
		fc.options().copyDefaults(true);
		Main.getInstance().saveConfig();
	}

	public static void loadConfiguration(){
		Settings.sectorsAmount = fc.getInt("options.sectorsAmount");
		Settings.sectorSize = fc.getInt("options.sectorSize");
		Settings.border = fc.getInt("options.mapBorder");
		Settings.world = fc.getString("options.defaultWorld");
		Settings.debug = fc.getBoolean("options.debug");
		Settings.spawn = new Location(Bukkit.getWorld(Settings.world), fc.getInt("options.spawn.x"), fc.getInt("options.spawn.y"), fc.getInt("options.spawn.z"));
		Settings.spawn.setPitch(fc.getInt("options.spawn.pitch"));
		Settings.spawn.setY(fc.getInt("options.spawn.yaw"));
		
		Settings.mysqlhost = fc.getString("options.mysql.host");
		Settings.mysqlport = fc.getInt("options.mysql.port");
		Settings.mysqluser = fc.getString("options.mysql.user");
		Settings.mysqlpass = fc.getString("options.mysql.pass");
		Settings.mysqldb = fc.getString("options.mysql.db");
		
		List<String> sectors = fc.getStringList("sectors.enabled");
		int count = 1;
		for(String s : sectors){
			Sector sector = SectorManager.createSector(count, LocationUtil.getLocationFromXZ(fc.getInt("sectors.list." + s + ".x"), fc.getInt("sectors.list." + s + ".z")), fc.getString("sectors.list." + s + ".sectorname"), fc.getInt("sectors.list." + s + ".borderx"), fc.getInt("sectors.list." + s + ".borderz"));
			Logger.info("Sector '" + s + "' (X: " + sector.getCenter().getX() + ", Z: " + sector.getCenter().getZ() + ", BUNGEECORD: " + sector.getConnectId() + ") has been loaded.");
			count++;
		}
		
		Logger.info("Configuration loaded.");
	}
	
}
