package net.xayanix.nssv.sektory.managers;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Damageable;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import net.xayanix.nssv.sektory.basic.Logger;
import net.xayanix.nssv.sektory.basic.Main;
import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.sektory.objects.User;
import net.xayanix.nssv.sektory.utils.ChatUtil;
import net.xayanix.nssv.sektory.utils.InventoryUtil;
import net.xayanix.nssv.sektory.utils.ItemUtil;
import net.xayanix.nssv.sektory.utils.LocationUtil;
import net.xayanix.nssv.sektory.utils.PotionUtil;

public class UserManager {
	
	public static HashMap<String, User> users = new HashMap<String, User>();
	
	public static User createUser(Player p){
		User user = new User();
		user.setLocation(p.getLocation());
		users.put(p.getName(), user);
		return user;
	}
	
	public static User getUser(Player p){
		if(users.containsKey(p.getName())) return users.get(p.getName());
		else return createUser(p);
	}
	
	@SuppressWarnings("deprecation")
	public static void sendPlayerInfo(final Player p){
		final Long startTime = System.currentTimeMillis();
		if(Settings.debug){
			Logger.warn("Sending player data...");
		}
		Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), new Runnable() {
			@Override
			public void run() {
				ChatUtil.sendMessage(p, " &8�&6 Zapisywanie ekwipunku...");
				String is = ItemUtil.itemStackArrayToBase64(p.getInventory().getContents());
				String ec = ItemUtil.itemStackArrayToBase64(p.getEnderChest().getContents());
				String potions = PotionUtil.serializePotionEffects(p);
				double y = p.getLocation().getY() + 1;
				String armorr = ItemUtil.itemStackArrayToBase64(p.getInventory().getArmorContents());
				
				DatabaseManager.executeQuery("DELETE FROM `player_data` WHERE `nick` = '" + p.getName() +"'");
				DatabaseManager.executeQuery("INSERT INTO `player_data` (`id`, `nick`, `x`, `y`, `z`, `yaw`, `pitch`, `hp`, `gamemode`, `inventory`, `armor`, `enderchest`, `potions`, `level`, `exp`, `antylogout`, `sector`) VALUES (NULL, '" + p.getName() + "', '" + p.getLocation().getX() + "', '" + y + "', '" + p.getLocation().getZ() + "', '" + p.getLocation().getYaw() + "', '" + p.getLocation().getPitch() + "', '" + ((Damageable) p).getHealth() + "', '" + p.getGameMode().getValue() +"', '" + is + "', '" + armorr + "', '" + ec + "', '" + potions + "', '" + p.getLevel() + "', '" + p.getExp() + "', '0', '" + Main.currentSector.getConnectId() + "');");			
			
				if(Settings.debug){
					final Long startTime2 = System.currentTimeMillis() - startTime;
					Logger.warn("Done! " + startTime2 + "ms");
					p.sendMessage(ChatUtil.fixColors("&8#&a Stan Twojego ekwipunku zostal zapisany."));
				}
			}
		});
		
		
	}
	
	@SuppressWarnings("deprecation")
	public static void sendPlayerInfo(final Player p, final Location location){
		final Long startTime = System.currentTimeMillis();
		if(Settings.debug){
			Logger.warn("Sending player data...");
		}
		Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), new Runnable() {
			@Override
			public void run() {
				String is = ItemUtil.itemStackArrayToBase64(p.getInventory().getContents());
				String ec = ItemUtil.itemStackArrayToBase64(p.getEnderChest().getContents());
				String potions = PotionUtil.serializePotionEffects(p);
				double y = location.getY() + 1;
				String armorr = ItemUtil.itemStackArrayToBase64(p.getInventory().getArmorContents());
				
				DatabaseManager.executeQuery("DELETE FROM `player_data` WHERE `nick` = '" + p.getName() +"'");
				DatabaseManager.executeQuery("INSERT INTO `player_data` (`id`, `nick`, `x`, `y`, `z`, `yaw`, `pitch`, `hp`, `gamemode`, `inventory`, `armor`, `enderchest`, `potions`, `level`, `exp`, `antylogout`, `sector`) VALUES (NULL, '" + p.getName() + "', '" + location.getX() + "', '" + y + "', '" + location.getZ() + "', '" + p.getLocation().getYaw() + "', '" + p.getLocation().getPitch() + "', '" + ((Damageable) p).getHealth() + "', '" + p.getGameMode().getValue() +"', '" + is + "', '" + armorr + "', '" + ec + "', '" + potions + "', '" + p.getLevel() + "', '" + p.getExp() + "', '0', '" + Main.currentSector.getConnectId() + "');");			
			
				if(Settings.debug){
					final Long startTime2 = System.currentTimeMillis() - startTime;
					Logger.warn("Done! " + startTime2 + "ms");
				}
			}
		});
		
		
	}
	
	@SuppressWarnings("deprecation")
	public static void sendPlayerInfoMainThread(final Player p, final Location location){
		final Long startTime = System.currentTimeMillis();
		if(Settings.debug){
			Logger.warn("Sending player data...");
		}
		
		String is = ItemUtil.itemStackArrayToBase64(p.getInventory().getContents());
		String ec = ItemUtil.itemStackArrayToBase64(p.getEnderChest().getContents());
		String potions = PotionUtil.serializePotionEffects(p);
		double y = location.getY() + 1;
		String armorr = ItemUtil.itemStackArrayToBase64(p.getInventory().getArmorContents());
				
		DatabaseManager.executeQuery("DELETE FROM `player_data` WHERE `nick` = '" + p.getName() +"'");
		DatabaseManager.executeQuery("INSERT INTO `player_data` (`id`, `nick`, `x`, `y`, `z`, `yaw`, `pitch`, `hp`, `gamemode`, `inventory`, `armor`, `enderchest`, `potions`, `level`, `exp`, `antylogout`, `sector`) VALUES (NULL, '" + p.getName() + "', '" + location.getX() + "', '" + y + "', '" + location.getZ() + "', '" + p.getLocation().getYaw() + "', '" + p.getLocation().getPitch() + "', '" + ((Damageable) p).getHealth() + "', '" + p.getGameMode().getValue() +"', '" + is + "', '" + armorr + "', '" + ec + "', '" + potions + "', '" + p.getLevel() + "', '" + p.getExp() + "', '0', '" + Main.currentSector.getConnectId() + "');");			
		
		if(Settings.debug){
			final Long startTime2 = System.currentTimeMillis() - startTime;
			Logger.warn("Done! " + startTime2 + "ms");
		}
	}
	
	public static void downloadPlayerInfo(final Player p){
		final Long startTime = System.currentTimeMillis();
		if(Settings.debug){
			Logger.warn("Downloading player data...");
		}
		Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), new Runnable() {
			@SuppressWarnings("deprecation")
			@Override
			public void run() {
				try {
					ChatUtil.sendMessage(p, " &8�&6 Przywracanie ekwipunku...");
					InventoryUtil.clearInventory(p);
					p.getEnderChest().clear();
					ResultSet rs = DatabaseManager.getQueryResult("SELECT * FROM `player_data` WHERE `nick` = '" + p.getName() + "' LIMIT 1;");
					if(rs.next()){
						if(Settings.debug){
							Logger.warn("Player data found.");
						}
						Location location = new Location(Bukkit.getWorld(Settings.world), rs.getInt("x"), rs.getInt("y"), rs.getInt("z"));
						location.setYaw(rs.getInt("yaw"));
						location.setPitch(rs.getInt("pitch"));
						LocationUtil.teleportMainThread(p, location);
						p.setHealth((rs.getInt("hp") > 0) ? rs.getInt("hp") : 20);
						p.setFoodLevel(20);
						
						InventoryUtil.clearInventory(p);
						
						p.giveExp(rs.getInt("exp"));
						p.setLevel(rs.getInt("level"));
						
						p.setGameMode(GameMode.getByValue(rs.getInt("gamemode")));
						ItemStack[] is = ItemUtil.itemStackArrayFromBase64(rs.getString("inventory"));
						ItemStack[] ec = ItemUtil.itemStackArrayFromBase64(rs.getString("enderchest"));
						ItemStack[] armor = ItemUtil.itemStackArrayFromBase64(rs.getString("armor"));
						Collection<PotionEffect> potions = PotionUtil.deserializePotionEffects(rs.getString("potions"));
						
						p.getInventory().setContents(is);
						p.getEnderChest().setContents(ec);
						p.getInventory().setArmorContents(armor);
						
						for(PotionEffect pe : potions){
							p.addPotionEffect(pe);
						}
						p.updateInventory();
						ChatUtil.sendMessage(p, " &8�&a Tw�j ekwipunek zostal przywr�cony.");
					}
					else{
						Bukkit.getServer().getScheduler().runTaskLater(Main.getInstance(), new Runnable() {
							public void run(){
								p.teleport(LocationUtil.getValidRandomCords(Main.currentSector));
								InventoryUtil.clearInventory(p);
								p.getEnderChest().clear();
								if(Settings.debug){
									Logger.warn("User created.");
								}
								ChatUtil.sendMessage(p, " &8�&c Twoje konto zostalo utworzone.");
							}
						}, 0);
					}
					rs.close();
					if(Settings.debug){
						final Long startTime2 = System.currentTimeMillis() - startTime;
						Logger.warn("Done! " + startTime2 + "ms");
					}
					
				} catch (SQLException | IOException e) {
					e.printStackTrace();
				}
			}
		});
		
	}

}
