package net.xayanix.nssv.sektory.managers;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import net.xayanix.nssv.sektory.basic.Settings;
import net.xayanix.nssv.sektory.objects.Sector;
import net.xayanix.nssv.sektory.utils.LocationUtil;

public class SectorManager {
	
	private static List<Sector> sectors = new ArrayList<Sector>();
	public static Sector border;
	public static Sector undefined;
	
	public static Sector createSector(int id, Location center, String sectorId, int borderx, int borderz){
		Sector sector = new Sector();
		sector.setId(id);
		sector.setCenter(center);
		sector.setBungeeId(sectorId);
		sectors.add(sector);
		sector.setMaxX(borderx);
		sector.setMaxZ(borderz);
		return sector;
	}
	
	public static void loadSectors(){
		border = new Sector();
		border.setId(0);
		border.setBungeeId("BORDER");
		
		undefined = new Sector();
		undefined.setId(-1);
		undefined.setBungeeId("POZA_MAPA");
	} 
	
	public static List<Sector> getSectors(){
		return sectors;
	}
	
	public static Sector getSector(int id){
		for(Sector s : sectors){
			if(s.getId() == id){
				return s;
			}
		}
		return null;
	}
	
	public static Sector getSector(String id){
		for(Sector s : sectors){
			if(s.getConnectId().equalsIgnoreCase(id)){
				return s;
			}
		}
		return null;
	}
	
	public static Sector getSector(Location location){
		int x = (int) location.getX();
		int z = (int) location.getZ();
		if(isBorder(location)){
			return border;
		}
		for(Sector s : getSectors()){
			
			int xcenter = (int) s.getCenter().getX();
			int zcenter = (int) s.getCenter().getZ();
			
			int sectormax_x;
			int sectormin_x;
			
			int sectormax_z;
			int sectormin_z;
			
			sectormax_x = xcenter + s.getMaxX();
			sectormin_x = xcenter - s.getMaxX();
			
			sectormax_z = zcenter + s.getMaxZ();
			sectormin_z = zcenter - s.getMaxZ();
		
			if(x < sectormax_x && x > sectormin_x && z < sectormax_z && z > sectormin_z){
				return s;
			}
		}
		
		return undefined;
	}
	
	public static Sector getSector(Player player){
		Location location = player.getLocation();
		int x = (int) location.getX();
		int z = (int) location.getZ();
		if(isBorder(location)){
			return border;
		}
		for(Sector s : getSectors()){
			
			int xcenter = (int) s.getCenter().getX();
			int zcenter = (int) s.getCenter().getZ();
			
			int sectormax_x;
			int sectormin_x;
			
			int sectormax_z;
			int sectormin_z;
			
			sectormax_x = xcenter + s.getMaxX();
			sectormin_x = xcenter - s.getMaxX();
			
			sectormax_z = zcenter + s.getMaxZ();
			sectormin_z = zcenter - s.getMaxZ();
		
			if(x < sectormax_x && x > sectormin_x && z < sectormax_z && z > sectormin_z){
				return s;
			}
		}
		
		return undefined;
	}
	
	public static Boolean isBorder(Location location){
		int x = (int) Math.floor(location.getX());
		int z = (int) Math.floor(location.getZ());
		for(int i = 1; i <= Settings.sectorsAmount; i++){
			if(x == i * Settings.sectorSize || z == i * Settings.sectorSize){
				return true;
			}
		}
		return false;
	}
	
	public static int borderXDistance(Location location){
		Sector sector = getSector(location);
		if(sector.getConnectId().equalsIgnoreCase("BORDER") || sector.getConnectId().equalsIgnoreCase("POZA_MAPA")){
			return 0;
		}
		int x = (int) Math.floor(sector.getCenter().getX()) + sector.getMaxX();
		int distance = LocationUtil.distance(x, (int) location.getX());
		if(distance > sector.getMaxX()){
			x = (int) Math.floor(sector.getCenter().getX()) - sector.getMaxX();
			distance = LocationUtil.distance(x, (int) location.getX());
		}
		return sector.getMaxX() - distance;
	}
	
	public static int borderZDistance(Location location){
		Sector sector = getSector(location);
		if(sector.getConnectId().equalsIgnoreCase("BORDER") || sector.getConnectId().equalsIgnoreCase("POZA_MAPA")){
			return 0;
		}
		int z = (int) Math.floor(sector.getCenter().getZ()) + sector.getMaxZ();
		int distance = LocationUtil.distance(z, (int) location.getZ());
		if(distance > sector.getMaxZ()){
			z = (int) Math.floor(sector.getCenter().getZ()) - sector.getMaxZ();
			distance = LocationUtil.distance(z, (int) location.getZ());
		}
		return sector.getMaxZ() - distance;
	}
	
	public static int borderXDistance(Location location, Sector sector){
		if(sector.getConnectId().equalsIgnoreCase("BORDER") || sector.getConnectId().equalsIgnoreCase("POZA_MAPA")){
			return 0;
		}
		int x = (int) Math.floor(sector.getCenter().getX()) + sector.getMaxX();
		int distance = LocationUtil.distance(x, (int) location.getX());
		if(distance > sector.getMaxX()){
			x = (int) Math.floor(sector.getCenter().getX()) - sector.getMaxX();
			distance = LocationUtil.distance(x, (int) location.getX());
		}
		return sector.getMaxX() - distance;
	}
	
	public static int borderZDistance(Location location, Sector sector){
		if(sector.getConnectId().equalsIgnoreCase("BORDER") || sector.getConnectId().equalsIgnoreCase("POZA_MAPA")){
			return 0;
		}
		int z = (int) Math.floor(sector.getCenter().getZ()) + sector.getMaxZ();
		int distance = LocationUtil.distance(z, (int) location.getZ());
		if(distance > sector.getMaxZ()){
			z = (int) Math.floor(sector.getCenter().getZ()) - sector.getMaxZ();
			distance = LocationUtil.distance(z, (int) location.getZ());
		}
		return sector.getMaxZ() - distance;
	}
	
	public static Boolean isNearNextSector(Location location, int distance){
		Sector sector = getSector(location);
		if(sector.getConnectId().equalsIgnoreCase("BORDER") || sector.getConnectId().equalsIgnoreCase("POZA_MAPA")){
			return true;
		}
		if(borderXDistance(location) >= sector.getMaxX() - distance || borderZDistance(location) >= sector.getMaxZ() - distance){
			return true;
		}
		return false;
	}
	
	public static int toNextSector(Location location){
		Sector sector = getSector(location);
		if(sector.getConnectId().equalsIgnoreCase("BORDER") || sector.getConnectId().equalsIgnoreCase("POZA_MAPA")){
			return 0;
		}
		
		int x = borderXDistance(location);
		int z = borderZDistance(location);
		if(x < z){
			return sector.getMaxZ() - z;
		}
		return sector.getMaxX() - x;
	}
	
	public static int getMaxDistance(Location location, Sector sector){
		int x = borderXDistance(location, sector);
		int z = borderZDistance(location, sector);
		if(x > z) return x;
		else return z;
	}

}
